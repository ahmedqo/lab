DataSheet({
    dataSheet: $dom("neo-datasheet"),
    colMapper: (props) => {
        return [{
            name: "full_name",
            text: $trans("Full name"),
            craft: {
                body: (row) => row.last_name.toUpperCase() + " " + $capitalize(row.first_name),
                csv: (row) => row.last_name.toUpperCase() + " " + $capitalize(row.first_name),
            },
        }, {
            name: "email",
            text: $trans("Email"),
        }, {
            name: "phone",
            text: $trans("Phone"),
        }, {
            visible: false,
            name: "birth_date",
            text: $trans("Birth date"),
            style: {
                head: { textAlign: "center" },
                body: { textAlign: "center" }
            },
            craft: {
                body: (row) => row.birth_date ? $moment(row.birth_date, $core.format) : empty(),
                csv: (row) => row.birth_date ? $moment(row.birth_date, $core.format) : empty(),
            },
        }, {
            visible: false,
            name: "gender",
            text: $trans("Gender"),
            style: {
                head: { width: 20, textAlign: "center" },
                body: { width: 20, textAlign: "center" }
            },
            craft: {
                body: (row) => row.gender ? $capitalize($trans(row.gender)) : empty(),
                csv: (row) => row.gender ? $capitalize($trans(row.gender)) : empty(),
            },
        }, {
            visible: false,
            name: "address",
            text: $trans("Address"),
            craft: {
                body: (row) => row.address ? $capitalize(row.address) : empty(),
                csv: (row) => row.address ? $capitalize(row.address) : empty(),
            },
        }, actionColumn(props)]
    }
});