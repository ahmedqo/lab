Neo.Validator = (function Validator() {
    const VALIDATOT_MAP = {
        NOW: function() {
            const d = new Date();
            return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
        },
        DATES: function(value, parts, query) {
            const contentDate = new Date(value);
            const compareDate = new Date(parts[0] === "today" ? VALIDATOT_MAP.NOW() : (Validator.Rules.date(parts[0]) ? parts[0] : query(`[name="${parts[0]}"]`).value));
            return [contentDate, compareDate];
        },
        SPLIT: function(parts) {
            return String(parts).split(",").map(e => e.trim()).filter(e => e.length);
        }
    }

    class Validator {
        static validate(selector, { rules = {}, message = {}, success = () => {}, failure = () => {}, execute = null }) {
            message = { success: {}, failure: {}, ...message };
            const element = typeof selector === "string" ? document.querySelector(selector) : selector;
            let isValid = true;

            Object.entries(rules).forEach(([rule, ruleValue]) => {
                const currentRules = typeof ruleValue === "string" ? ruleValue.split("|") : ruleValue;
                const currentField = element.querySelector(`[name="${rule}"]`);
                const currentValue = String(currentField.value || '').trim();
                let isSuccess = true;

                currentRules.some(ruleItem => {
                    const [ruleName, ruleValue] = ruleItem.split(":");
                    const normalizedRuleName = ruleName.toLowerCase();
                    const parts = String(ruleValue || '').trim().split(",").map(e => e.trim()).filter(e => e.length);

                    if (!Validator.Rules[normalizedRuleName]) return false;
                    const isValidRule = Validator.Rules[normalizedRuleName](
                        currentValue, parts, {
                            field: currentField,
                            query: (s) => element.querySelector(s),
                            queryAll: (s) => element.querySelectorAll(s),
                        });

                    if (!isValidRule) {
                        const failureMessage = message.failure[rule] || {};
                        const messageText = typeof failureMessage === "string" ? failureMessage : failureMessage[normalizedRuleName];
                        failure(currentField, normalizedRuleName, messageText);
                        isSuccess = false;
                        isValid = false;
                        return true; // Exit `some` loop
                    }

                    return false; // Continue `some` loop
                });

                if (isSuccess) {
                    success(currentField, message.success[rule]);
                }
            });

            return isValid && execute ? execute() : isValid;
        }

        static Rules = class Rules {
            static required = function required(value, parts, { field, queryAll }) {
                if (["checkbox", "radio"].includes(field.type)) {
                    const checkboxes = queryAll(`[name="${field.name}"]`);
                    return Array.from(checkboxes).some(checkbox => checkbox.checked);
                }
                return value !== "";
            }

            static required_if = function required_if(value, parts, { field, query, queryAll }) {
                const [fieldName, expectedValue] = parts;
                const matchingField = query(`[name="${fieldName}"]`);
                return !matchingField || expectedValue === String(matchingField.value).trim() ? Validator.Rules.required(value, "", { field, queryAll }) : true;
            }

            static required_unless = function required_unless(value, parts, { field, query, queryAll }) {
                const [fieldName, expectedValue] = parts;
                const matchingField = query(`[name="${fieldName}"]`);
                return !matchingField || expectedValue !== String(matchingField.value).trim() ? Validator.Rules.required(value, "", { field, queryAll }) : true;
            }

            static required_with = function required_with(value, parts, { field, query, queryAll }) {
                const isFieldPresent = parts.some(name => {
                    const fieldElement = query(`[name="${name}"]`);
                    return fieldElement && Validator.Rules.required(fieldElement.value, "", { field: fieldElement, queryAll });
                });
                return isFieldPresent ? Validator.Rules.required(value, "", { field, queryAll }) : true;
            }

            static required_without = function required_without(value, parts, { field, query }) {
                const isFieldPresent = parts.some(name => {
                    const fieldElement = query(`[name="${name}"]`);
                    return fieldElement && Validator.Rules.required(fieldElement.value, "", { field: fieldElement, queryAll });
                });
                return !isFieldPresent ? Validator.Rules.required(value, "", { field, queryAll }) : true;
            }

            static required_with_all = function required_with_all(value, parts, { field, query }) {
                const areFieldsPresent = parts.every(name => {
                    const fieldElement = query(`[name="${name}"]`);
                    return fieldElement && Validator.Rules.required(fieldElement.value, "", { field: fieldElement, queryAll });
                });
                return areFieldsPresent ? Validator.Rules.required(value, "", { field, queryAll }) : true;
            }

            static email = function email(value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(value);
            }

            static numeric = function numeric(value) {
                return !isNaN(value) && value !== "";
            }

            static integer = function integer(value) {
                return Number.isInteger(Number(value));
            }

            static float = function float(value) {
                return !isNaN(parseFloat(value));
            }

            static alpha = function alpha(value) {
                const alphaRegex = /^[A-Za-z]+$/;
                return alphaRegex.test(value);
            }

            static date = function date(value) {
                const dateRegex = /^(?:(?:\d{4}[-/]\d{2}[-/]\d{2})|(?:\d{2}[-/]\d{2}[-/]\d{4}))$/;
                return dateRegex.test(value);
            }

            static date_before = function date_before(value, parts, { query }) {
                const [contentDate, compareDate] = VALIDATOT_MAP.DATES(value, parts, query);
                return contentDate < compareDate;
            }

            static date_after = function date_after(value, parts, { query }) {
                const [contentDate, compareDate] = VALIDATOT_MAP.DATES(value, parts, query);
                return contentDate > compareDate;
            }

            static date_before_or_equal = function date_before_or_equal(value, parts, { query }) {
                const [contentDate, compareDate] = VALIDATOT_MAP.DATES(value, parts, query);
                return contentDate <= compareDate;
            }

            static date_after_or_equal = function date_after_or_equal(value, parts, { query }) {
                const [contentDate, compareDate] = VALIDATOT_MAP.DATES(value, parts, query);
                return contentDate >= compareDate;
            }

            static url = function url(value) {
                const urlRegex = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i;
                return urlRegex.test(value);
            }

            static phone = function phone(value) {
                const phoneNumberRegex = /^(?:\+*([0-9]{3}|0))(?:[ \-]?[0-9]){9}$/;
                return phoneNumberRegex.test(value);
            }

            static length = function length(value, parts) {
                const [minLength, maxLength] = parts.map(Number);
                return (minLength === undefined || value.length >= minLength) &&
                    (maxLength === undefined || value.length <= maxLength);
            }

            static strong = function strong(value, parts) {
                return parts.every(rule => {
                    switch (rule) {
                        case "uppercase":
                            return /[A-Z]/.test(value);
                        case "lowercase":
                            return /[a-z]/.test(value);
                        case "numeric":
                            return /\d/.test(value);
                        case "special":
                            return /[!@#$%^&*]/.test(value);
                        default:
                            return true;
                    }
                });
            }

            static min = function min(value, parts) {
                return parseFloat(value) >= parseFloat(parts[0]);
            }

            static max = function max(value, parts) {
                return parseFloat(value) <= parseFloat(parts[0]);
            }

            static regex = function regex(value, parts) {
                const customRegex = new RegExp(parts[0]);
                return customRegex.test(value);
            }

            static size = function size(value, parts, { field }) {
                const maxSize = parseInt(parts[0]);
                return field.files[0].size <= maxSize;
            }

            static type = function type(value, parts, { field }) {
                return VALIDATOT_MAP.SPLIT(field.accept).some(type => parts.includes(type));
            }

            static match = function match(value, parts, { query }) {
                const matchField = query(`[name="${parts[0]}"]`);
                return matchField && value === String(matchField.value).trim();
            }

            static clash = function clash(value, parts, extra) {
                return !Validator.Rules.match(value, parts, extra);
            }

            static exists = function exists(value, parts) {
                return parts.includes(value);
            }

            static absent = function absent(value, parts, extra) {
                return !Validator.Rules.exists(value, parts, extra);
            }

            static equal = function equal(value, parts) {
                return value === parts[0];
            }

            static different = function different(value, parts) {
                return !Validator.Rules.equal(value, parts);
            }

            static include = function include(value, parts) {
                return parts.some(v => value.includes(v));
            }

            static exclude = function exclude(value, parts) {
                return parts.every(v => !value.includes(v));
            }

            static contain = function contain(value, parts) {
                return parts.some(substring => value.includes(substring));
            }
        }
    }

    return Validator;
})();