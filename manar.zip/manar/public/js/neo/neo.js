const fs = require('fs');
const path = require('path');
const min = require("uglify-js");

const CONFIG = {
        PATH: {
            INPUT: process.argv[2],
            OUTPUT: process.argv[3],
        },
        FLAG: process.argv[4],
        COMPONENTS: (process.argv[5] || "").split(',').map(e => e.trim())
    },
    Properties = {},
    LOGGER = [];

function Sketch(source) {
    const NEO_SKETCH = {
        ESCAPE_MAP: {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&apos;",
        },
        DELEMITERS: [/\{\$/, /\$\}/],
        VARIABLES: [/\{\{/, /\}\}/],
        CHAINED: /([.]+[\w\d-_]+)(?=(?:[^'"`]|["'`][^'"`]*["'`])*$)/g,
        HELPERS: /(?<!["'`])@+(\w+)(?!["'`])/g,
        get PARSED() {
            return new RegExp(
                `(${NEO_SKETCH.DELEMITERS[0].source}.*?${NEO_SKETCH.DELEMITERS[1].source}|${NEO_SKETCH.VARIABLES[0].source}.*?${NEO_SKETCH.VARIABLES[1].source}|${NEO_SKETCH.VARIABLES[0].source}|${NEO_SKETCH.DELEMITERS[0].source})`
            )
        },
        get FULL_TOKEN() {
            return new RegExp('^' + NEO_SKETCH.DELEMITERS[0].source + '\\s*(\\w+)\\s*(.*)?' + NEO_SKETCH.DELEMITERS[1].source + '$')
        },
        get IS_LOGIC() {
            return new RegExp('^' + NEO_SKETCH.DELEMITERS[0].source)
        },
        get IS_VARIABLE() {
            return new RegExp('^' + NEO_SKETCH.VARIABLES[0].source)
        },
        get VARIABLE_CONTENT() {
            return new RegExp('^' + NEO_SKETCH.VARIABLES[0].source + '(.*)' + NEO_SKETCH.VARIABLES[1].source + '$')
        },
        EACH: function(iterable, callback) {
            if (!iterable) return iterable;
            if (Array.isArray(iterable)) {
                iterable.forEach((value, index) => callback(index, value, {
                    index,
                    round: index + 1,
                    odd: index % 2 > 0,
                    even: index % 2 === 0,
                    first: index === 0,
                    last: index === iterable.length - 1,
                }));
            } else {
                let index = 0;
                for (const key in iterable) {
                    if (!iterable.hasOwnProperty(key)) continue;
                    callback(key, iterable[key], {
                        index,
                        round: index + 1,
                        odd: index % 2 > 0,
                        even: index % 2 === 0,
                        first: index === 0,
                        last: index + 1 === Object.keys(iterable).length,
                    });
                    index++;
                }
            }
        },
        SIZE: function(iterable) {
            try { return Object.keys(iterable).length; } catch { return 0; }
        },
        ESCAPE: function(string) {
            return string.replace(/[&<>"']/g, char => NEO_SKETCH.ESCAPE_MAP[char] || char);
        },
        REGEX: function(line) {
            return line
                .replace(NEO_SKETCH.HELPERS, (_, name) => name === "loop" ? "$LOOP$" : "$HELPER$." + name)
                .replace(NEO_SKETCH.CHAINED, obj => "[\"" + obj.substring(1) + "\"]");
        },
        LOOP: function(args) {
            const mth = /\[(.*),(.*)\]/g.exec(args[0]);
            const arr = args[1].trim();
            const val = args[0].trim();
            const key = "_";
            return [arr, mth ? mth[1].trim() : key, mth ? mth[2].trim() : val];
        },
        TOKENS: function(source) {
            if (!source) return [];
            let line = 1,
                col = 1;
            return source.split(NEO_SKETCH.PARSED).filter(t => t.length > 0).map(value => {
                const result = { value, line, col };
                const lastIndex = value.lastIndexOf("\n");
                if (lastIndex >= 0) {
                    const linebreaks = value.split("\n").length - 1;
                    line += linebreaks;
                    col = value.length - lastIndex;
                } else col += value.length;
                return result;
            });
        },
        TOKEN: function(token, options) {
            if (NEO_SKETCH.IS_LOGIC.test(token.value)) {
                const match = NEO_SKETCH.FULL_TOKEN.exec(token.value);
                return ["macro", "endmacro"].includes(match[1].toLowerCase()) ?
                    (options.macro = match[1].toLowerCase() === "macro", "") :
                    NEO_SKETCH.LOGIC(match[1].toLowerCase())(match[2] && NEO_SKETCH.REGEX(match[2].trim()));
            } else if (NEO_SKETCH.IS_VARIABLE.test(token.value)) {
                const ref = NEO_SKETCH.VARIABLE_CONTENT.exec(token.value);
                const match = ref ? ref[1] : "";
                return "$ADDJSX$(" + (match[0] === ">" ? "$ESCAPE$(" + NEO_SKETCH.REGEX(match.substring(1).trim()) + ")" : NEO_SKETCH.REGEX(match.trim())) + ");";
            } else if (token.value.length) {
                return options.macro ? token.value.replace(/(\n|\s+)/g, " ") : "$ADDTXT$(\"" + token.value.replace(/(`|'|")/g, "\\$1") + "\");";
            }
        },
        LOGIC: function(name) {
            return {
                //  ($ make name = "ahmed" $)
                make: (line) => "var " + line + ";",

                //  ($ code name = "ahmed" $)
                code: (line) => line + ";",

                //  ($ until age > 10 $)
                until: (line) => "while(!(" + line + ")){",
                //  ($ enduntil $)
                enduntil: () => "}",

                //  ($ until age < 10 $)
                while: (line) => "while(" + line + "){",
                //  ($ endwhile $)
                endwhile: () => "}",

                //  ($ unless age < 10 $)
                unless: (line) => "if(!(" + line + ")){",
                //  ($ endunless $)
                endunless: () => "}",

                //  ($ each name into names $)
                each: (line) => {
                    var [arr, key, val] = NEO_SKETCH.LOOP(line.split(/into|INTO/));
                    return "$EACH$(" + arr + ",function(" + key + "," + val + ",$LOOP$){";
                },
                //  ($ endeach $)
                endeach: () => "});",

                //  ($ forelse name into names $)
                forelse: (line) => {
                    var [arr, key, val] = NEO_SKETCH.LOOP(line.split(/into|INTO/));
                    return "if($SIZE$(" + arr + ")){$EACH$(" + arr + ",function(" + key + "," + val + ",$LOOP$){";
                },
                //  ($ empty $)
                empty: () => "})}else{",
                //  ($ endforelse $)
                endforelse: () => "}",

                //  ($ if age > 10 $)
                if: (line) => "if(" + line + "){",
                //  ($ elif age === 18 $)
                elif: (line) => "}else if(" + line + "){",
                //  ($ else $)
                else: () => "}else{",
                //  ($ endif $)
                endif: () => "}",

                //  ($ try $)
                try: () => "try{",
                //  ($ catch error $)
                catch: (line) => "}catch(" + line + "){",
                //  ($ finally $)
                finally: () => "}finally{",
                //  ($ endtry $)
                endtry: () => "}",

                //  ($ info name, age $)
                info: (line) => "console['trace'](" + line + ");",
                //  ($ warn name, age $)
                warn: (line) => "console['warn'](" + line + ");",
                //  ($ error name, age $)
                error: (line) => "console['error'](" + line + ");",
            }[name.toLowerCase()];
        },
        ERROR: function(err, token) {
            err.message += `\n    at ${token.value} (${token.line}:${token.col})`;
            if (!err.location) err.location = { line: token.line, col: token.col };
            return err;
        },
        COMPILE: function(source) {
            const tokens = NEO_SKETCH.TOKENS(source);
            var parsed = NEO_SKETCH.PARSE(tokens);
            parsed = parsed.replace(/(\n|\n\s+)/g, "\\n");

            return "return function($CONTEXT$,$HELPER$,$EACH$,$SIZE$,$ESCAPE$,$ERROR$){var $TXT$=[],$JSX$=[],$INDEX$=0,$LINE$=0,$COL$=0;function $ADDTXT$($LINE$){if(!$TXT$[$INDEX$]){$TXT$[$INDEX$]=''}$TXT$[$INDEX$]=($TXT$[$INDEX$]+$LINE$).replace(/\\n(:?\\s*\\n)+/g,'\\n')}function $ADDJSX$($LINE$){$JSX$[$INDEX$]=$LINE$,$INDEX$++}with($CONTEXT$||{}){try{" +
                parsed + "}catch(e){throw new $ERROR$([e.message,'\\n\\tat','Line:','\"'+$LINE$+'\"','Col:','\"'+$COL$+'\"'].join(' '))}}return [$TXT$,...$JSX$]}"
        },
        PARSE: function(tokens) {
            if (!tokens.length) return "";
            const options = { macro: false };
            return tokens.reduce((carry, token) => {
                try { return carry + "$LINE$=" + token.line + ";$COL$=" + token.col + ";" + NEO_SKETCH.TOKEN(token, options); } catch (err) { throw NEO_SKETCH.ERROR(err, token); }
            }, "");
        },
        TEST: function(source) {
            return source.startsWith("return function($CONTEXT$,$HELPER$,$EACH$,$SIZE$,$ESCAPE$,$ERROR$){var $TXT$=[],$JSX$=[],$INDEX$=0,$LINE$=0,$COL$=0;function $ADDTXT$($LINE$){if(!$TXT$[$INDEX$]){$TXT$[$INDEX$]=''}$TXT$[$INDEX$]=($TXT$[$INDEX$]+$LINE$).replace(/\\n(:?\\s*\\n)+/g,'\\n')}function $ADDJSX$($LINE$){$JSX$[$INDEX$]=$LINE$,$INDEX$++}");
        }
    };

    return NEO_SKETCH.COMPILE(source);
};

function minify(content) {
    return content
        .replace(/("|'|`)/g, "\$1")
        .split(/\r\n|\n/)
        .map(e => e.trim() + "\n")
        .reduce((a, c) => a + c, "")
        .trim();
}

function getProps(source) {
    const match = source.match(/<template\s+([^>]*)>/);
    if (!match) return {};

    const attributeString = match[1];
    const attributeRegex = /(\S+)=["']?((?:.(?!["']?\s+(?:\S+)=|[>"']))+.)["']?/g;

    attributeString.replace(attributeRegex, function(match, name, value) {
        Properties[name] = value;
    });
}

function getTags(source, tag) {
    const regex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\/${tag}>`, 'gi');
    const matches = source.match(regex);
    return matches ? matches.map(match => {
        tag === "template" && getProps(match);
        return match.replace(new RegExp(`<${tag}[^>]*>|<\/${tag}>`, 'gi'), '').trim()
    })[0] : "";
}

function execFile(input, output) {
    if (path.extname(input) !== ".neo") return;

    console.log("\ncompiling: " + path.basename(output));

    const source = fs.readFileSync(input, 'utf8');

    const content = {
        tpl: Sketch(minify(getTags(source, "template"))),
        css: Sketch(minify(`<style>${getTags(source, "style")}</style>`)),
        code: (getTags(source, "script") || "export default {}").replace(/\s*export default\s*/g, ""),
    }

    const component = min.minify(`//? Component: ${Properties.name}\nNeo.Component({wrap:false,ctl:${"ctl" in Properties},tag:"${Properties.name}",tpl: ${JSON.stringify(content.tpl)},css:${JSON.stringify(content.css)}})(${content.code}).define();`, { mangle: true, compress: true, rename: true });

    if (component.error) console.log(component.error);

    if (["--use", "--mix"].includes(CONFIG.FLAG)) {
        LOGGER.push(component.code);
    }

    //else fs.writeFileSync(output.replace(/.neo/, ".js"), component.code, 'utf8');

    if ("require" in Properties) Properties.require.split(",").map(file => {
        if (!CONFIG.COMPONENTS.includes(file)) CONFIG.COMPONENTS.push(file);
    });

    console.log("compiled: " + path.basename(output.replace(/.neo/, ".js")));
}

function execDir(input, output) {
    output = output || input;
    if (!fs.existsSync(output) && !["--use", "--mix"].includes(CONFIG.FLAG)) {
        fs.mkdirSync(output, { recursive: true });
    }

    const files = fs.readdirSync(input);

    files.forEach(file => {
        if (CONFIG.FLAG === "--use" && !CONFIG.COMPONENTS.includes(path.basename(file).split(".")[0])) return
        const inputFilePath = path.join(input, file);
        const outputFilePath = path.join(output, file);
        execFile(inputFilePath, outputFilePath);
    });
}

function exec(input, output) {
    const stats = fs.statSync(input);

    if (stats.isFile()) execFile(input, output);
    if (stats.isDirectory()) execDir(input, output);

    fs.writeFileSync(output + ".min.js", LOGGER.join(''), 'utf8');
}

exec(CONFIG.PATH.INPUT, CONFIG.PATH.OUTPUT);