const Neo = (function Neo() {
    const NEO_TEXT_SYMBOL = Symbol.for("TEXT_SYMBOL"),
        NEO_LOAD_MAPS = [],
        NEO_NODE_MAPS = {},
        NEO_HELPER = {
            COLORS: {
                WHITE: "254 254 254",
                LIGHT: "245 245 245",
                SHADE: "209 209 209",
                PRIME: "33 150 243",
                BLACK: "29 29 29",
                RED: {
                    50: "254 242 242",
                    100: "254 226 226",
                    200: "254 202 202",
                    300: "252 165 165",
                    400: "248 113 113",
                    500: "239 68 68",
                    600: "220 38 38",
                    700: "185 28 28",
                    800: "153 27 27",
                    900: "127 29 29",
                    950: "69 10 10",
                },
                GRAY: {
                    50: "249 250 251",
                    100: "243 244 246",
                    200: "229 231 235",
                    300: "209 213 219",
                    400: "156 163 175",
                    500: "107 114 128",
                    600: "75 85 99",
                    700: "55 65 81",
                    800: "31 41 55",
                    900: "17 24 39",
                    950: "3 7 18",
                },
                BLUE: {
                    50: "239 246 255",
                    100: "219 234 254",
                    200: "191 219 254",
                    300: "147 197 253",
                    400: "96 165 250",
                    500: "59 130 246",
                    600: "37 99 235",
                    700: "29 78 216",
                    800: "30 64 175",
                    900: "30 58 138",
                    950: "23 37 84",
                },
                GREEN: {
                    50: "240 253 244",
                    100: "220 252 231",
                    200: "187 247 208",
                    300: "134 239 172",
                    400: "74 222 128",
                    500: "34 197 94",
                    600: "22 163 74",
                    700: "21 128 61",
                    800: "22 101 52",
                    900: "20 83 45",
                    950: "5 46 22",
                },
                YELLOW: {
                    50: "254 252 232",
                    100: "254 249 195",
                    200: "254 240 138",
                    300: "253 224 71",
                    400: "250 204 21",
                    500: "234 179 8",
                    600: "202 138 4",
                    700: "161 98 7",
                    800: "133 77 14",
                    900: "113 63 18",
                    950: "66 32 6",
                },
                PURPLE: {
                    50: "250 245 255",
                    100: "243 232 255",
                    200: "233 213 255",
                    300: "216 180 254",
                    400: "192 132 252",
                    500: "168 85 247",
                    600: "147 51 234",
                    700: "126 34 206",
                    800: "107 33 168",
                    900: "88 28 135",
                    950: "59 7 100",
                },
            },
            SIZES: {
                XSMALL: "0.75rem",
                SMALL: "0.875rem",
                BASE: "1rem",
                MEDIUM: "1.125rem",
                LARGE: "1.25rem",
                XLARGE: "1.5rem",
            },
            LINES: {
                THIN: "0.75rem",
                XSMALL: "1rem",
                SMALL: "1.25rem",
                BASE: "1.5rem",
                MEDIUM: "1.75rem",
                LARGE: "1.75rem",
                XLARGE: "2rem",
            },
            STYLES: {
                "animation-iteration-count": true,
                "border-image-slice": true,
                "border-image-width": true,
                "column-count": true,
                "counter-increment": true,
                "counter-reset": true,
                flex: true,
                "flex-grow": true,
                "flex-shrink": true,
                "font-size-adjust": true,
                "font-weight": true,
                "line-height": true,
                "nav-index": true,
                opacity: true,
                order: true,
                orphans: true,
                "tab-size": true,
                widows: true,
                "z-index": true,
                "pitch-range": true,
                richness: true,
                "speech-rate": true,
                stress: true,
                volume: true,
                "lood-opacity": true,
                "mask-box-outset": true,
                "mask-border-outset": true,
                "mask-box-width": true,
                "mask-border-width": true,
                "shape-image-threshold": true,
            },
            MOMENT: {
                $: {
                    props: [
                        ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    ],
                    zeros: function(nbr, len) {
                        for (var sign = nbr < 0 ? "-" : "", output = Math.abs(nbr).toString(); output.length < len;) output = "0" + output;
                        return sign + output;
                    },
                    clean: function(input) {
                        var matches = input.match(/^'([^]*?)'?$/);
                        return matches ? matches[1].replace(/''/g, "'") : input;
                    },
                },
                y: (date, token) => {
                    var signedYear = date.getFullYear(),
                        year = signedYear > 0 ? signedYear : 1 - signedYear;
                    return NEO_HELPER.MOMENT.$.zeros("yy" === token ? year % 100 : year, token.length);
                },
                m: (date, token) => {
                    var month = date.getMonth();
                    switch (token) {
                        case "mmm":
                            return Helper.trans(NEO_HELPER.MOMENT.$.props[0][month]).slice(0, 3);
                        case "mmmm":
                            return Helper.trans(NEO_HELPER.MOMENT.$.props[0][month]);
                        default:
                            return NEO_HELPER.MOMENT.$.zeros(month + 1, token.length);
                    }
                },
                d: (date, token) => {
                    switch (token) {
                        case "ddd":
                            return Helper.trans(NEO_HELPER.MOMENT.$.props[1][date.getDay()]).slice(0, 3);
                        case "dddd":
                            return Helper.trans(NEO_HELPER.MOMENT.$.props[1][date.getDay()]);
                        default:
                            return NEO_HELPER.MOMENT.$.zeros(date.getDate(), token.length);
                    }
                },
                A: (date, token) => {
                    var dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
                    switch (token) {
                        case "A":
                        case "AA":
                            return dayPeriodEnumValue.toUpperCase();
                        case "AAA":
                            return dayPeriodEnumValue;
                        case "AAAAA":
                            return dayPeriodEnumValue[0];
                        case "AAAA":
                        default:
                            return "am" === dayPeriodEnumValue ? "a.m." : "p.m.";
                    }
                },
                h: (date, token) => {
                    return NEO_HELPER.MOMENT.$.zeros(date.getHours() % 12 || 12, token.length);
                },
                H: (date, token) => {
                    return NEO_HELPER.MOMENT.$.zeros(date.getHours(), token.length);
                },
                M: (date, token) => {
                    return NEO_HELPER.MOMENT.$.zeros(date.getMinutes(), token.length);
                },
                S: (date, token) => {
                    return NEO_HELPER.MOMENT.$.zeros(date.getSeconds(), token.length);
                },
            }
        },
        NEO_SKETCH = {
            ESCAPE_MAP: {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&apos;",
            },
            DELEMITERS: [/\{\$/, /\$\}/],
            VARIABLES: [/\{\{/, /\}\}/],
            CHAINED: /([.]+[\w\d-_]+)(?=(?:[^'"`]|["'`][^'"`]*["'`])*$)/g,
            HELPERS: /(?<!["'`])@+(\w+)(?!["'`])/g,
            get PARSED() {
                return new RegExp(
                    `(${NEO_SKETCH.DELEMITERS[0].source}.*?${NEO_SKETCH.DELEMITERS[1].source}|${NEO_SKETCH.VARIABLES[0].source}.*?${NEO_SKETCH.VARIABLES[1].source}|${NEO_SKETCH.VARIABLES[0].source}|${NEO_SKETCH.DELEMITERS[0].source})`
                )
            },
            get FULL_TOKEN() {
                return new RegExp('^' + NEO_SKETCH.DELEMITERS[0].source + '\\s*(\\w+)\\s*(.*)?' + NEO_SKETCH.DELEMITERS[1].source + '$')
            },
            get IS_LOGIC() {
                return new RegExp('^' + NEO_SKETCH.DELEMITERS[0].source)
            },
            get IS_VARIABLE() {
                return new RegExp('^' + NEO_SKETCH.VARIABLES[0].source)
            },
            get VARIABLE_CONTENT() {
                return new RegExp('^' + NEO_SKETCH.VARIABLES[0].source + '(.*)' + NEO_SKETCH.VARIABLES[1].source + '$')
            },
            EACH: function(iterable, callback) {
                if (!iterable) return iterable;
                if (Array.isArray(iterable)) {
                    iterable.forEach((value, index) => callback(index, value, {
                        index,
                        round: index + 1,
                        odd: index % 2 > 0,
                        even: index % 2 === 0,
                        first: index === 0,
                        last: index === iterable.length - 1,
                    }));
                } else {
                    let index = 0;
                    for (const key in iterable) {
                        if (!iterable.hasOwnProperty(key)) continue;
                        callback(key, iterable[key], {
                            index,
                            round: index + 1,
                            odd: index % 2 > 0,
                            even: index % 2 === 0,
                            first: index === 0,
                            last: index + 1 === Object.keys(iterable).length,
                        });
                        index++;
                    }
                }
            },
            SIZE: function(iterable) {
                try { return Object.keys(iterable).length; } catch { return 0; }
            },
            ESCAPE: function(string) {
                return string.replace(/[&<>"']/g, char => NEO_SKETCH.ESCAPE_MAP[char] || char);
            },
            REGEX: function(line) {
                return line
                    .replace(NEO_SKETCH.HELPERS, (_, name) => name === "loop" ? "$LOOP$" : "$HELPER$." + name)
                    .replace(NEO_SKETCH.CHAINED, obj => "[\"" + obj.substring(1) + "\"]");
            },
            LOOP: function(args) {
                const mth = /\[(.*),(.*)\]/g.exec(args[0]);
                const arr = args[1].trim();
                const val = args[0].trim();
                const key = "_";
                return [arr, mth ? mth[1].trim() : key, mth ? mth[2].trim() : val];
            },
            TOKENS: function(source) {
                if (!source) return [];
                let line = 1,
                    col = 1;
                return source.split(NEO_SKETCH.PARSED).filter(t => t.length > 0).map(value => {
                    const result = { value, line, col };
                    const lastIndex = value.lastIndexOf("\n");
                    if (lastIndex >= 0) {
                        const linebreaks = value.split("\n").length - 1;
                        line += linebreaks;
                        col = value.length - lastIndex;
                    } else col += value.length;
                    return result;
                });
            },
            TOKEN: function(token, options) {
                if (NEO_SKETCH.IS_LOGIC.test(token.value)) {
                    const match = NEO_SKETCH.FULL_TOKEN.exec(token.value);
                    return ["macro", "endmacro"].includes(match[1].toLowerCase()) ?
                        (options.macro = match[1].toLowerCase() === "macro", "") :
                        NEO_SKETCH.LOGIC(match[1].toLowerCase())(match[2] && NEO_SKETCH.REGEX(match[2].trim()));
                } else if (NEO_SKETCH.IS_VARIABLE.test(token.value)) {
                    const ref = NEO_SKETCH.VARIABLE_CONTENT.exec(token.value);
                    const match = ref ? ref[1] : "";
                    return "$ADDJSX$(" + (match[0] === ">" ? "$ESCAPE$(" + NEO_SKETCH.REGEX(match.substring(1).trim()) + ")" : NEO_SKETCH.REGEX(match.trim())) + ");";
                } else if (token.value.length) {
                    return options.macro ? token.value.replace(/(\n|\s+)/g, " ") : "$ADDTXT$(\"" + token.value.replace(/(`|'|")/g, "\\$1") + "\");";
                }
            },
            LOGIC: function(name) {
                return {
                    //  ($ make name = "ahmed" $)
                    make: (line) => "var " + line + ";",

                    //  ($ code name = "ahmed" $)
                    code: (line) => line + ";",

                    //  ($ until age > 10 $)
                    until: (line) => "while(!(" + line + ")){",
                    //  ($ enduntil $)
                    enduntil: () => "}",

                    //  ($ until age < 10 $)
                    while: (line) => "while(" + line + "){",
                    //  ($ endwhile $)
                    endwhile: () => "}",

                    //  ($ unless age < 10 $)
                    unless: (line) => "if(!(" + line + ")){",
                    //  ($ endunless $)
                    endunless: () => "}",

                    //  ($ each name into names $)
                    each: (line) => {
                        var [arr, key, val] = NEO_SKETCH.LOOP(line.split(/into|INTO/));
                        return "$EACH$(" + arr + ",function(" + key + "," + val + ",$LOOP$){";
                    },
                    //  ($ endeach $)
                    endeach: () => "});",

                    //  ($ forelse name into names $)
                    forelse: (line) => {
                        var [arr, key, val] = NEO_SKETCH.LOOP(line.split(/into|INTO/));
                        return "if($SIZE$(" + arr + ")){$EACH$(" + arr + ",function(" + key + "," + val + ",$LOOP$){";
                    },
                    //  ($ empty $)
                    empty: () => "})}else{",
                    //  ($ endforelse $)
                    endforelse: () => "}",

                    //  ($ if age > 10 $)
                    if: (line) => "if(" + line + "){",
                    //  ($ elif age === 18 $)
                    elif: (line) => "}else if(" + line + "){",
                    //  ($ else $)
                    else: () => "}else{",
                    //  ($ endif $)
                    endif: () => "}",

                    //  ($ try $)
                    try: () => "try{",
                    //  ($ catch error $)
                    catch: (line) => "}catch(" + line + "){",
                    //  ($ finally $)
                    finally: () => "}finally{",
                    //  ($ endtry $)
                    endtry: () => "}",

                    //  ($ info name, age $)
                    info: (line) => "console['trace'](" + line + ");",
                    //  ($ warn name, age $)
                    warn: (line) => "console['warn'](" + line + ");",
                    //  ($ error name, age $)
                    error: (line) => "console['error'](" + line + ");",
                }[name.toLowerCase()];
            },
            ERROR: function(err, token) {
                err.message += `\n    at ${token.value} (${token.line}:${token.col})`;
                if (!err.location) err.location = { line: token.line, col: token.col };
                return err;
            },
            COMPILE: function(source) {
                const tokens = NEO_SKETCH.TOKENS(source);
                var parsed = NEO_SKETCH.PARSE(tokens);
                parsed = parsed.replace(/(\n|\n\s+)/g, "\\n");

                return "return function($CONTEXT$,$HELPER$,$EACH$,$SIZE$,$ESCAPE$,$ERROR$){var $TXT$=[],$JSX$=[],$INDEX$=0,$LINE$=0,$COL$=0;function $ADDTXT$($LINE$){if(!$TXT$[$INDEX$]){$TXT$[$INDEX$]=''}$TXT$[$INDEX$]=($TXT$[$INDEX$]+$LINE$).replace(/\\n(:?\\s*\\n)+/g,'\\n')}function $ADDJSX$($LINE$){$JSX$[$INDEX$]=$LINE$,$INDEX$++}with($CONTEXT$||{}){try{" +
                    parsed + "}catch(e){throw new $ERROR$([e.message,'\\n\\tat','Line:','\"'+$LINE$+'\"','Col:','\"'+$COL$+'\"'].join(' '))}}return [$TXT$,...$JSX$]}"
            },
            PARSE: function(tokens) {
                if (!tokens.length) return "";
                const options = { macro: false };
                return tokens.reduce((carry, token) => {
                    try { return carry + "$LINE$=" + token.line + ";$COL$=" + token.col + ";" + NEO_SKETCH.TOKEN(token, options); } catch (err) { throw NEO_SKETCH.ERROR(err, token); }
                }, "");
            },
            TEST: function(source) {
                return source.startsWith("return function($CONTEXT$,$HELPER$,$EACH$,$SIZE$,$ESCAPE$,$ERROR$){var $TXT$=[],$JSX$=[],$INDEX$=0,$LINE$=0,$COL$=0;function $ADDTXT$($LINE$){if(!$TXT$[$INDEX$]){$TXT$[$INDEX$]=''}$TXT$[$INDEX$]=($TXT$[$INDEX$]+$LINE$).replace(/\\n(:?\\s*\\n)+/g,'\\n')}function $ADDJSX$($LINE$){$JSX$[$INDEX$]=$LINE$,$INDEX$++}");
            }
        },
        NEO_PARSER = {
            JOIN: new RegExp("<\\[\\((\\d+)\\)\\]>"),
            NUMBER: new RegExp("\\d+"),
            COMPOSE: function(source, props) {
                return source.reduce((acc, part, i) => acc + part + (i < props.length ? ["string", "number", "boolean"].includes(typeof props[i]) ? props[i] : `<[(${i})]>` : ""), "").trim();
            },
            PARSE: function(source) {
                const template = document.createElement("template");
                template.innerHTML = source;
                return template.content;
            }
        },
        NEO_DRIVER = {
            SVG_NODES: {
                svg: true,
                animate: true,
                animateMotion: true,
                animateTransform: true,
                circle: true,
                clipPath: true,
                defs: true,
                desc: true,
                discard: true,
                ellipse: true,
                feBlend: true,
                feColorMatrix: true,
                feFiberTransfer: true,
                feComposite: true,
                feConvolveMatrix: true,
                feDiffuseLighting: true,
                feDisplacementMap: true,
                feDistantLight: true,
                feDropShadow: true,
                feFlood: true,
                feFuncA: true,
                feFuncB: true,
                feFuncG: true,
                feFuncR: true,
                feGaussianBlur: true,
                feImage: true,
                feMerge: true,
                feMergeNode: true,
                feMorphology: true,
                feOffset: true,
                fePointLight: true,
                feSpecularLighting: true,
                feSpotLight: true,
                feTile: true,
                feTurbulence: true,
                filter: true,
                foreignObject: true,
                g: true,
                hatch: true,
                hatchpath: true,
                image: true,
                line: true,
                linearGradient: true,
                marker: true,
                mask: true,
                metadata: true,
                mpath: true,
                path: true,
                pattern: true,
                polygon: true,
                polyline: true,
                radialGradient: true,
                rect: true,
                script: true,
                set: true,
                stop: true,
                style: true,
                switch: true,
                symbol: true,
                text: true,
                textPath: true,
                title: true,
                tspan: true,
                use: true,
                compiler: true,
                animateColor: true,
                "missing-glyph": true,
                font: true,
                "font-face": true,
                "font-face-format": true,
                "font-face-name": true,
                "font-face-src": true,
                "font-face-uri": true,
                hkern: true,
                vkern: true,
                solidcolor: true,
                altGlyph: true,
                altGlyphDef: true,
                altGlyphItem: true,
                glyph: true,
                glyphRef: true,
                tref: true,
                cursor: true,
            },
            FLATTEN(array) {
                return array.reduce((flat, toFlatten) => [...flat, ...(Array.isArray(toFlatten) ? NEO_DRIVER.FLATTEN(toFlatten) : [toFlatten])], []);
            }
        };

    class Instance {
        constructor(dom, fiber, children) {
            this.dom = dom;
            this.fiber = fiber;
            this.children = children;
        }
    }

    class Fiber {
        constructor(type = null, props = {}) {
            this.type = type;
            this.props = props;
            this.props.children = this.props.children || [];
        }
    }

    class Parser {
        constructor(source, ...props) {
            this.source = source;
            this.props = props;
        }

        crawl(node) {
            if (node.nodeType !== Node.TEXT_NODE) {
                const props = (node.attributes ? [...node.attributes] : []).reduce((acc, attr) => {
                    const numName = attr.name.match(NEO_PARSER.NUMBER) || [];
                    const numValue = attr.value.match(NEO_PARSER.NUMBER) || [];

                    const name = NEO_PARSER.JOIN.test(attr.name) ? this.props[+numName[0]] : attr.name;
                    const value = NEO_PARSER.JOIN.test(attr.value) ? this.props[+numValue[0]] : attr.value;

                    acc[name] = value;
                    return acc;
                }, {});

                const children = [...node.childNodes]
                    .map(c => this.crawl(c))
                    .filter(Boolean);

                return new Fiber(node.nodeName.toLowerCase(), {...props, children });
            }

            const value = node.nodeValue.trim();
            if (!value) return null;

            const token = value.replace(/\s\s+|\r?\n/g, "");
            if (!NEO_PARSER.JOIN.test(token)) {
                return new Fiber(NEO_TEXT_SYMBOL, { nodeValue: value });
            }

            const element = this.props[+token.match(NEO_PARSER.NUMBER)];
            return element instanceof Sketch ?
                element.exec() :
                new Fiber(element, { children: [] });
        }

        exec() {
            const parsed = NEO_PARSER.PARSE(NEO_PARSER.COMPOSE(this.source, this.props));
            return this.crawl(parsed).props.children;
        }
    }

    class Helper {
        static secure = function secure(original, alternative) {
            return this.truty(original) ? original : alternative;
        }

        static random = function random(length = 10) {
            const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
        }

        static option = function option(cases, target) {
            if (!cases || !target) return;
            for (const [keys, value] of Object.entries(cases)) {
                if (keys.split(",").some(k => k.trim() === target)) return value();
            }
        }

        static choice(items, length = 1) {
            if (!items) return length > 1 ? [] : undefined;
            const isObj = !Array.isArray(items);
            const entries = isObj ? Object.entries(items) : items;
            const size = entries.length;

            if (!size) return length > 1 ? [] : undefined;

            const shuffled = [...entries];
            for (let i = size - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
            }

            const picked = shuffled.slice(0, Math.min(length, size));

            return isObj ? picked.reduce((acc, [k, v]) => (acc[k] = v, acc), {}) : (length > 1 ? picked : picked[0]);
        }

        static falsy = function falsy(data) {
            return [
                "false", "null", "undefined", "0", ""
            ].includes(String(data).trim());
        }

        static truty = function truty(data) {
            return !this.falsy(data);
        }

        static trans = function trans(text, context = {}) {
            var dict = Neo.Locales[context["#locale"] || document.documentElement.lang || "en"];
            return ((dict && dict[text]) || text).replace(/#([\w\d._-]+)/g, (full, key) => context[key] || full);
        }

        static range = function range(startOrEnd, end, step = 1) {
            const start = end === undefined ? 0 : +startOrEnd;
            end = end === undefined ? +startOrEnd : +end;
            const length = Math.ceil((end - start) / step);
            return Array.from({ length }, (_, index) => start + index * step);
        }

        static style = function style(cssObj) {
            return Object.entries(cssObj)
                .filter(([, value]) => this.truty(value))
                .map(([key, value]) => {
                    const rule = Str.kebab(key);
                    if (typeof value === "number" && !(rule in NEO_HELPER.STYLES)) value += "px";
                    return `${rule}:${value};`;
                })
                .join("");
        }

        static when = function when(condition, truecase, falsecase) {
            const branch = this.truty(condition) ? truecase : falsecase;
            return typeof branch === "function" ? branch(condition) : branch;
        }
    }

    class Theme {
        static MEDIA = ["", "-o-", "-ms-", "-moz-", "-webkit-"];

        static assign = function assign(type, name, value) {
            const group = type && NEO_HELPER[type.toUpperCase()];
            if (group) group[name.toUpperCase()] = value;
        }

        static colors = function colors(name, shade, opacity) {
            name = name.toUpperCase();
            const isobj = typeof NEO_HELPER.COLORS[name] === "object";
            return "rgb(" + ((isobj ? NEO_HELPER.COLORS[name][shade] : NEO_HELPER.COLORS[name]) || NEO_HELPER.COLORS.BLACK) + " / " + (((isobj ? opacity : shade) || 100) / 100) + ")";
        }

        static sizes = function sizes(name) {
            return NEO_HELPER.SIZES[name.toUpperCase()];
        }

        static lines = function lines(name) {
            return NEO_HELPER.LINES[name.toUpperCase()];
        }

        static layer = function layer() {
            const all = [...document.querySelectorAll("body *")];
            const nested = all.flatMap(el => ("root" in el ? [...el.root.querySelectorAll("*"), el] : [el]));

            const zIndexes = nested.map(el => parseFloat(getComputedStyle(el).zIndex))
                .filter(z => !Number.isNaN(z));

            return Math.max(0, ...zIndexes) + 1;
        }
    }

    class Str {
        static moment = function moment(date, format = "yyyy-mm-dd") {
            if (!(date instanceof Date) && typeof date !== "string") return null;
            date = (date instanceof Date) ? date : new Date(date);

            const tokens = (format).match(/(\w)\1*|''|'(''|[^'])+('|$)|./g);
            if (!tokens) return null;

            return tokens
                .map(function(substringing) {
                    if ("''" === substringing) return "'";
                    var firstCharacter = substringing[0];
                    if ("'" === firstCharacter) return NEO_HELPER.MOMENT.$.clean(substringing);
                    var formatter = NEO_HELPER.MOMENT[firstCharacter];
                    return formatter ? formatter(date, substringing) : substringing;
                })
                .join("");
        }

        static kebab = function kebab(string = "") {
            return string.replace(/([a-z])([A-Z])/g, "$1-$2").split(/[-_.\\\/\s]/g).join("-").toLowerCase();
        }

        static snake = function snake(string = "") {
            return string.replace(/[-_.\\\/\s](\w+)/g, (_, w) => w[0].toUpperCase() + w.slice(1).toLowerCase());
        }

        static money = function money(number, zeros = 2) {
            if (Number.isNaN(+number)) return null;

            return number.toLocaleString('en-US', {
                minimumFractionDigits: Math.max(zeros, (number.toFixed(zeros).toString().split('.')[1] || '').length)
            });
        }

        static compact = function compact(number = 0, zeros = 0) {
            if (Number.isNaN(+number)) return null;

            return new Intl.NumberFormat('en-US', {
                notation: 'compact',
                compactDisplay: 'short',
                minimumFractionDigits: Math.max(zeros, (number.toString().split('.')[1] || '').length)
            }).format(number);
        }

        static titlize = function titlize(string = "") {
            return (!string || typeof string !== 'string') ? '' : string.trim().replace(/\b\w/g, (char) =>
                char.toUpperCase()
            );
        }

        static capitalize = function capitalize(string = "") {
            return (!string || typeof string !== 'string') ? '' : string.trim().charAt(0).toUpperCase() + string.trim().slice(1);
        }
    }

    class Driver {
        constructor(container, tree, refs = {}) {
            this.container = container;
            this.instance = null;
            this.refs = refs;
            this.tree = tree;
        }

        createNode(fiber) {
            const { type, props } = fiber;
            const dom =
                type === NEO_TEXT_SYMBOL ?
                document.createTextNode("") : type instanceof HTMLElement ? type :
                type in NEO_DRIVER.SVG_NODES ?
                document.createElementNS("http://www.w3.org/2000/svg", type) :
                document.createElement(type);
            const children = this.reconcileChildren({ dom }, fiber);
            this.props(dom, {}, props, this.refs);
            return new Instance(dom, fiber, children);
        }

        reconcile(parentDom, oldNode, fiber) {
            var node;
            if (null == oldNode) {
                if (Array.isArray(fiber)) {
                    node = fiber.map((e) => this.createNode(e));
                    node.forEach((e) => {
                        parentDom.appendChild(e.dom);
                    });
                } else {
                    node = this.createNode(fiber);
                    if (Array.isArray(node.dom)) {
                        NEO_DRIVER.FLATTEN(node.dom).forEach((e) => {
                            parentDom.appendChild(e);
                        });
                    } else {
                        node.dom && parentDom.appendChild(node.dom);
                    }
                }
                return node;
            }

            if (null == fiber) {
                if (Array.isArray(oldNode)) {
                    oldNode.forEach((e) => {
                        parentDom.removeChild(e.dom);
                    });
                } else {
                    oldNode.dom && parentDom.removeChild(oldNode.dom);
                }
                return null;
            }

            if (Array.isArray(oldNode) && Array.isArray(fiber)) {
                return this.reconcileChildren({ dom: parentDom, children: oldNode }, { props: { children: fiber } });
            }

            if ((oldNode.fiber || {}).type !== fiber.type) {
                node = this.createNode(fiber);
                if (oldNode.dom || oldNode[0].dom) {
                    parentDom.replaceChild(node.dom, oldNode.dom || oldNode[0].dom);
                }
                return node;
            }

            if (typeof fiber.type === "string" || fiber.type === NEO_TEXT_SYMBOL) {
                oldNode.children = this.reconcileChildren(oldNode, fiber);
                this.props(oldNode.dom, oldNode.fiber.props, fiber.props, this.refs);
                oldNode.fiber = fiber;
                return oldNode;
            }

            return undefined;
        }

        reconcileChildren(oldNode, fiber) {
            const oldChildNodes = (oldNode.children || []).filter((node) => null != node),
                childElements = (fiber.props.children || []).filter((node) => null != node),
                length = Math.max(oldChildNodes.length, childElements.length),
                children = [];

            for (var i = 0; i < length; i++) {
                const childNode = this.reconcile(oldNode.dom, oldChildNodes[i], childElements[i]);
                children.push(childNode);
            }

            return children;
        }

        props(node, prev, next, refs) {
            this.clearProps(node, prev, next);
            this.mountProps(node, next, refs);
        }

        mountProps(node, next, refs) {
            for (var prop in next) {
                if (prop === "children") continue;

                const tag = node && node.tagName && node.tagName.toLowerCase(),
                    isObj = prop.split(".").length > 1,
                    isSvg = tag in NEO_DRIVER.SVG_NODES,
                    isEvent = prop.startsWith("@"),
                    isRef = prop === "ref",
                    isProp = prop in node;

                if (isEvent) this.mountEvents(node, prop, next[prop]);
                else if (isProp && !isSvg) {
                    node[prop] = ["false", "true"].includes(next[prop]) ? eval(next[prop]) : next[prop];
                } else if (isObj) {
                    const props = prop.split("."),
                        target = props.pop(),
                        object = props.reduce((carry, curr) => carry[curr], node);
                    object[target] = next[prop];
                } else if (isRef) {
                    if (refs[next[prop]])
                        Array.isArray(refs[next[prop]]) ?
                        refs[next[prop]].push(node) :
                        (refs[next[prop]] = [refs[next[prop]], node]);
                    else refs[next[prop]] = node;
                } else node.setAttribute(prop, next[prop]);
            }
        }

        clearProps(node, prev, next) {
            this.clearEvents(node, next);
            for (var prop in prev) {
                if (!(prop in next)) {
                    const tag = node && node.tagName && node.tagName.toLowerCase(),
                        isObj = prop.split(".").length > 1,
                        isSvg = tag in NEO_DRIVER.SVG_NODES,
                        isProp = prop in node;

                    if (isProp && !isSvg) node[prop] = "";
                    else if (isObj)
                        this.applyObject(
                            node, {
                                [prop]: "",
                            },
                            prop
                        );
                    else node.removeAttribute(prop);
                }
            }
        }

        mountEvents(node, name, callable) {
            const eventString = name.split(":"),
                eventName = eventString.shift().substring(1);

            node.listeners = node.listeners || {};
            if (!node.listeners[name] ||
                (node.listeners[name] && node.listeners[name].toString() !== callable.toString())
            ) {
                node.listeners[name] = callable;
                node["on" + eventName] = (event) => {
                    (eventString[0] || "").split("|").forEach((type) => {
                        switch (type) {
                            case "prevent":
                                event.preventDefault();
                            case "propagation":
                                event.stopPropagation();
                            case "immediate":
                                event.stopImmediatePropagation();
                        }
                    });
                    callable(event);
                }
            }
        }

        clearEvents(node, next) {
            for (const event in node.listeners) {
                if (!(event in next)) {
                    const eventString = event.split(":"),
                        eventName = eventString[0].substring(1);

                    node["on" + eventName] = null;
                    delete node.listeners[event];
                }
            }
        }

        exec(tree) {
            this.tree = tree || this.tree;
            for (let prop in this.refs) delete this.refs[prop];
            this.instance = this.reconcile(this.container, this.instance, this.tree);
        }
    }

    class Sketch {
        constructor(source, context, helpers = {}) {
            this.source = source
                .replace(/\n.*?(\(\$)-/g, '$1')
                .replace(/-(\$\)).*?\n/g, '$1')
                .replace(/\n.*?(\{\{)-/g, '$1')
                .replace(/-(}\}).*?\n/g, '$1');

            this.helpers = {...Helper, ...helpers };
            this.context = context;
            this.compiledFn = null;
        }

        frech(context, helpers) {
            this.helpers = {...Helper, ...helpers };
            this.context = context;
        }

        build() {
            if (!this.compiledFn) {
                const fnSource = NEO_SKETCH.TEST(this.source) ? this.source : NEO_SKETCH.COMPILE(this.source);
                this.compiledFn = new Function("", fnSource)();
            }
            return this.compiledFn(this.context, this.helpers, NEO_SKETCH.EACH, NEO_SKETCH.SIZE, NEO_SKETCH.ESCAPE, Error);
        }

        str() {
            const source = this.build(this.source);
            const [txtParts, ...jsxParts] = source;
            return txtParts
                .reduce((acc, part, i) => acc + part + (["string", "number", "boolean"].includes(typeof jsxParts[i]) ? jsxParts[i] : ""), "")
                .trim();
        }

        exec() {
            return new Parser(...this.build(this.source)).exec();
        }
    }

    class Segment {
        constructor(root, sketch, context = {}) {
            this.Sketch = new Sketch(sketch, context, { this: this });
            this.Driver = new Driver(root, []);
            this.Signals = [];
            this.initReactivity();
            this.upgrade();
        }

        initReactivity() {
            Object.keys(this.context).forEach(key => {
                var val = this.context[key];
                if (typeof val === "function") {
                    this.context[key] = val.bind(this);
                    return;
                }

                Object.defineProperty(this.context, key, {
                    get: () => val,
                    set: next => {
                        if (val === next) return;
                        val = next;
                        this.upgrade();
                    }
                });
            });
        }

        setSignal(callback) {
            if (typeof callback === "function") {
                this.Signals.push(callback.bind(this));
            }
        }

        setContext(props) {
            let upgrade = false;
            for (const [key, val] of Object.entries(props)) {
                if (this.context[key] !== val) {
                    this.context[key] = val;
                    upgrade = true;
                }
            }
            if (upgrade) this.upgrade();
        }

        upgrade() {
            this.Driver.exec(this.Sketch.exec());
            this.Signals.forEach(fn => fn());
        }

        get context() {
            return this.Sketch.context;
        }
    }

    const Component = function Component({ tag = "", ctl = false, tpl = "", css = "", wrap = true }) {
        return function({ attrs = [], dense = {}, props = {}, rules = {}, state = {}, cycle = {} }) {
            return class extends HTMLElement {
                static {
                    Object.assign(this, dense);
                    if (ctl) this.formAssociated = true;
                    this.observedAttributes = attrs;
                    this.selector = tag;

                    this.define = function(name = this.selector) {
                        if (!customElements.get(name)) {
                            NEO_NODE_MAPS[name] = this;
                            customElements.define(name, this);
                        }
                        return this;
                    };
                }

                cache = {
                    drive: null,
                    props: {},
                    state: {},
                    css: new Sketch(wrap ? `<sty>${css}</style>` : css),
                    tpl: new Sketch(tpl),
                };
                props = {};
                state = {};
                rules = {};
                refs = {};
                cycle = {
                    started() {},
                    mounted() {},
                    adopted() {},
                    updated() {},
                    removed() {},
                    crafted() {},
                    ...cycle,
                };

                constructor() {
                    super();
                    this.root = this.attachShadow({ mode: "open" });

                    if (ctl) this.setupFormControls();

                    this.initReactivity("props", props, attrs);
                    this.initReactivity("state", state);

                    Object.entries(rules).forEach(([k, fn]) => {
                        if (typeof fn === "function") this.rules[k] = fn.bind(this);
                    });

                    Object.entries(cycle).forEach(([k, fn]) => {
                        if (typeof fn === "function") this.cycle[k] = fn.bind(this);
                    });

                    this.craft();
                    this.cycle.started();
                    this.emit("started");
                }

                setupFormControls() {
                    this.ctl = this.attachInternals();
                    Object.defineProperties(this, {
                        form: { get: () => this.ctl.form },
                        name: { get: () => this.getAttribute("name") },
                        validity: { get: () => this.ctl.validity },
                        willValidate: { get: () => this.ctl.willValidate },
                        validationMessage: { get: () => this.ctl.validationMessage },
                    });
                    this.checkValidity = () => this.ctl.checkValidity();
                    this.reportValidity = () => this.ctl.reportValidity();
                }

                initReactivity(type, initial, attrs = []) {
                    Object.keys(initial).forEach((key) => {
                        this.cache[type][key] = initial[key];
                        Object.defineProperty(this[type], key, {
                            get: () => this.cache[type][key],
                            set: (next) => {
                                const prev = this.cache[type][key];
                                if (prev === next) return;
                                this.cache[type][key] = next;

                                const attr = Str.kebab(key);
                                if (type === "props" && attrs.includes(attr)) {
                                    next ? this.getAttribute(attr) !== String(next) && this.setAttribute(attr, next) : this.removeAttribute(attr);
                                }

                                this.craft();
                                this.cycle.updated(key, prev, next, type);
                                this.emit("updated", { name: key, type, prev, next });
                            },
                        });

                        if (type === "props")
                            Object.defineProperty(this, key, Object.getOwnPropertyDescriptor(this[type], key));
                    });
                }

                attributeChangedCallback(name, prev, next) {
                    this.cycle.updated(name, prev, next, "attrs");
                }

                connectedCallback() {
                    this.cycle.mounted();
                    this.emit("mounted");
                }

                disconnectedCallback() {
                    this.cycle.removed();
                    this.emit("removed");
                }

                adoptedCallback() {
                    this.cycle.adopted();
                    this.emit("adopted");
                }

                craft() {
                    const context = {
                        props: this.cache.props,
                        state: this.cache.state,
                        rules: this.rules,
                        refs: this.refs,
                        this: this,
                    };

                    this.cache.css.frech(context, context);
                    this.cache.tpl.frech(context, context);

                    const TREE = [
                        ...this.cache.css.exec(),
                        ...this.cache.tpl.exec(),
                    ];

                    if (!this.cache.drive) this.cache.drive = new Driver(this.root, [], this.refs);

                    this.cache.drive.exec(TREE);
                    this.cycle.crafted();
                    this.emit("crafted");
                }

                emit(name, data, callable) {
                    const ev = new CustomEvent(name, {
                        bubbles: true,
                        cancelable: true,
                        composed: true,
                        detail: data,
                    });
                    this.dispatchEvent(ev);
                    if (!ev.defaultPrevented && callable) callable.call(this, ev);
                }

                setProps(newProps = {}) {
                    this.bulkUpdate("props", newProps);
                }

                setState(newState = {}) {
                    this.bulkUpdate("state", newState);
                }

                bulkUpdate(type, updates) {
                    let changed = {};
                    Object.entries(updates).forEach(([k, v]) => {
                        if (this.cache[type][k] !== v) {
                            changed[k] = this.cache[type][k];
                            this.cache[type][k] = v;
                        }
                    });

                    if (Object.keys(changed).length) {
                        this.craft();
                        Object.keys(changed).forEach((k) => {
                            this.cycle.updated(k, changed[k], this.cache[type][k], type);
                        });
                    }
                }
            };
        };
    }

    class Neo {
        static Wrapper = null;
        static Toaster = null;
        static Locales = {
            fr: {
                /** months */
                "January": "Janvier",
                "February": "Fevrier",
                "March": "Mars",
                "April": "Avril",
                "May": "Mai",
                "June": "Juin",
                "July": "Juillet",
                "August": "Août",
                "September": "Septembre",
                "October": "Octobre",
                "November": "Novembre",
                "December": "Decembre",
                /** days */
                "Sunday": "Dimanche",
                "Monday": "Lundi",
                "Tuesday": "Mardi",
                "Wednesday": "Mercredi",
                "Thursday": "Jeudi",
                "Friday": "Vendredi",
                "Saturday": "Samedi",
                /** components */
                "Print": "Imprimer",
                "Search": "Recherche",
                "Columns": "Colonnes",
                "Download": "Telecharger",
                "No data found": "Aucune donnee disponible",
            },
            ar: {
                /** months */
                "January": "يناير",
                "February": "فبراير",
                "March": "مارس",
                "April": "أبريل",
                "May": "مايو",
                "June": "يونيو",
                "July": "يوليو",
                "August": "أغسطس",
                "September": "سبتمبر",
                "October": "أكتوبر",
                "November": "نوفمبر",
                "December": "ديسمبر",
                /** days */
                "Sunday": "الأحد",
                "Monday": "الاثنين",
                "Tuesday": "الثلاثاء",
                "Wednesday": "الأربعاء",
                "Thursday": "الخميس",
                "Friday": "الجمعة",
                "Saturday": "السبت",
                /** components */
                "Print": "طباعة",
                "Search": "بحث",
                "Columns": "أعمدة",
                "Download": "تحميل",
                "No data found": "لا توجد بيانات",
            }
        }

        static load = function load(callable) {
            typeof callable === "function" && NEO_LOAD_MAPS.push(callable);
        };

        static upgrade = function upgrade() {
            Object.keys(NEO_NODE_MAPS).forEach(selector => {
                Array.from(document.querySelectorAll(selector), (el) => el.craft());
            });
        }

        static getComponent(name) {
            return NEO_NODE_MAPS[name];
        }
    }

    document.addEventListener("DOMContentLoaded", (e) => {
        NEO_LOAD_MAPS.forEach((callable) => callable(e));
        const root = getComputedStyle(document.documentElement);
        const keys = ["--prime", "--black", "--white", "--shade", "--light"];
        for (const key of keys) {
            const value = root.getPropertyValue(key).trim();
            value && Neo.Helper.Theme.assign("colors", key.replace("--", "").toUpperCase(), value);
        }
        Neo.upgrade();

        const wall = document.querySelector("neo-wall");
        document.body.removeAttribute("neo-close");
        wall && wall.remove();
    });

    Helper.Theme = Theme;
    Helper.Str = Str;

    Neo.Component = Component;
    Neo.Segment = Segment;
    Neo.Helper = Helper;
    Neo.Sketch = Sketch;
    Neo.Driver = Driver;

    return Neo;
})();