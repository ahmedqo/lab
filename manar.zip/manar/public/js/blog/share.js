const transfer = $dom("neo-dropzone[name=image]"),
    meta = $dom("meta[name=image]"),
    divs = $dom("[toggle]", { many: true }),
    lang = ["fr", "ar"];

if (meta) {
    const image = meta.content;
    meta.remove();
    transfer.dataset = [{ src: image }];
}

lang.forEach(l => {
    const content = $dom("textarea[name=content_" + l + "]");
    new Jodit(content, {
        toolbarAdaptive: false,
        minHeight: 300,
        uploader: {
            url: $routes.store,
            headers: {
                "X-CSRF-TOKEN": $routes.csrf
            },
        },
        filebrowser: {
            ajax: {
                url: $routes.index,
                headers: {
                    "X-CSRF-TOKEN": $routes.csrf
                }
            },
            fileRemove: {
                url: $routes.clear,
                method: "DELETE",
                headers: {
                    "X-CSRF-TOKEN": $routes.csrf
                },
                successStatuses: [200]
            },
        },
    });
});

divs.forEach(div => {
    const triggers = $dom("[data-target]", { context: div, many: true }),
        targets = $dom("[data-for]", { context: div, many: true });

    triggers.forEach(trigger => {
        trigger.addEventListener("click", e => {
            const target = $dom("[data-for=" + trigger.dataset.target + "]", { context: div });

            triggers.forEach(_ => {
                _.classList.remove("bg-x-prime", "text-x-white");
                _.classList.add("text-x-black", "border-b-x-shade");
            });
            targets.forEach(_ => {
                _.classList.remove("grid");
                _.classList.add("hidden");
            });

            trigger.classList.remove("text-x-black", "border-b-x-shade");
            trigger.classList.add("bg-x-prime", "text-x-white");
            target.classList.remove("hidden");
            target.classList.add("grid");
        });
    });
});