const $image = (payload, width) => {
        return `<img style="${Neo.Helper.style({
        background: Neo.Helper.Theme.colors("LIGHT"),
        width: width ? width : "100%",
        objectFit: "cover",
        aspectRatio: "1/1",
        display: "block",
        borderRadius: 4,
        height: "100%",
    })}" ${payload ? `src="${"/storage/IMAGES/" + payload.storage}" width="${payload.width}" height="${payload.height}"` : ""} />`;
}

DataSheet({
    dataSheet: $dom("neo-datasheet"),
    colMapper: (props) => {
        return [{
            name: "storage",
            text: $trans("Image"),
            style: {
                head: {width: 100, textAlign: "center"},
                body: {width: 100, textAlign: "center"},
            },
            craft: {
                body: (row) => $image(row.image),
                csv: (row) => row.image,
            },
        }, {
            name: "title",
            text: $trans("Title"),
            craft: {
                body: (row) => $titlize(row["title_" + document.documentElement.lang]),
                csv: (row) => $titlize(row["title_" + document.documentElement.lang]),
            },
        }, actionColumn(props)]
    }
});