<?php $__env->startSection('title', __('Edit profile')); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.profile.patch')); ?>" method="POST" class="w-full">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <neo-stepper step="step-1">
            <neo-stepper-item step="step-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The first name field is required')); ?>"}'
                    label="<?php echo e(__('First name')); ?> (*)" name="first_name" value="<?php echo e(old('first_name', $data->first_name)); ?>"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The last name field is required')); ?>"}'
                    label="<?php echo e(__('Last name')); ?> (*)" name="last_name" value="<?php echo e(old('last_name', $data->last_name)); ?>"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required|email"
                    errors='{"required": "<?php echo e(__('The email field is required')); ?>", "email": "<?php echo e(__('The email field must be a valid email')); ?>"}'
                    type="email" label="<?php echo e(__('Email')); ?> (*)" name="email" value="<?php echo e(old('email', $data->email)); ?>"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required|phone"
                    errors='{"required": "<?php echo e(__('The phone field is required')); ?>", "phone": "<?php echo e(__('The phone field must be a valid phone number')); ?>"}'
                    type="tel" label="<?php echo e(__('Phone')); ?> (*)" name="phone" value="<?php echo e(old('phone', $data->phone)); ?>"
                    class="w-full"></neo-textbox>
            </neo-stepper-item>
            <neo-stepper-item step="step-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-select label="<?php echo e(__('Gender')); ?>" name="gender" class="w-full">
                    <neo-select-popup>
                        <?php $__currentLoopData = Neo::genderList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <neo-select-option value="<?php echo e($gender); ?>"
                                <?php echo e($gender == old('gender', $data->gender) ? 'active' : ''); ?>>
                                <?php echo e(ucfirst(__($gender))); ?>

                            </neo-select-option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </neo-select-popup>
                </neo-select>
                <neo-datepicker <?php echo e(!Neo::locale('ar') ? 'full-day=3' : ''); ?> label="<?php echo e(__('Birth date')); ?>"
                    name="birth_date" format="<?php echo e(Neo::formatsList(Neo::preference('date_format'), 0)); ?>"
                    value="<?php echo e(old('birth_date', $data->birth_date)); ?>" class="w-full"></neo-datepicker>
                <neo-textarea label="<?php echo e(__('Address')); ?>" name="address" value="<?php echo e(old('address', $data->address)); ?>"
                    rows="4" class="w-full"></neo-textarea>
            </neo-stepper-item>
            <div slot="lower" class="w-full flex flex-wrap gap-6">
                <neo-button outline type="button" id="prev" style="display: none"
                    class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span><?php echo e(__('Prev')); ?></span>
                </neo-button>
                <neo-button id="save" style="display: none"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
                <neo-button outline type="button" id="next"
                    class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span><?php echo e(__('Next')); ?></span>
                </neo-button>
            </div>
        </neo-stepper>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\manar\resources\views/profile/patch.blade.php ENDPATH**/ ?>