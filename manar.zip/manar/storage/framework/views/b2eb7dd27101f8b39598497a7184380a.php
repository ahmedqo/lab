<div slot="footer" id="page-footer">
    <div class="banner"></div>
    <div class="content"></div>
</div>
<?php /**PATH P:\php\manar\resources\views/shared/page/foot.blade.php ENDPATH**/ ?>