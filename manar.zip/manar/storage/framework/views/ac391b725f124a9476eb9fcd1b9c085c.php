<div slot="header" id="page-header">
    
    <div id="text-row">
        <div class="space first"></div>
        <h1 id="text"><?php echo e(strtoupper(__(env('APP_NAME')))); ?></h1>
        <div class="space last"></div>
    </div>
</div>
<?php /**PATH P:\php\manar\resources\views/shared/page/head.blade.php ENDPATH**/ ?>