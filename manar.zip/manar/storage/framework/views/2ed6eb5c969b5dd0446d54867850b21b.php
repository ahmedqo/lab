<img slot="top" id="backgroun-image" src="<?php echo e(Neo::logo(true)); ?>" />
<?php if(Neo::preference()): ?>
    <style slot="styles" scoped>
        <?php echo e(Neo::colors(true)); ?>

    </style>
<?php endif; ?>
<?php echo $__env->make('shared.page.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared.page.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH P:\php\manar\resources\views/shared/page/print.blade.php ENDPATH**/ ?>