<link rel="stylesheet" href="<?php echo e(Neo::asset('css/font.min.css')); ?>" media="print" onload="this.media='all';" />
<link rel="stylesheet" href="<?php echo e(Neo::asset('css/index.min.css')); ?>" />
<?php /**PATH P:\php\manar\resources\views/shared/base/styles.blade.php ENDPATH**/ ?>