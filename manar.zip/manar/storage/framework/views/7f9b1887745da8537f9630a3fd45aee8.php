<script src="<?php echo e(Neo::asset('js/neo/index.min.js')); ?>"></script>
<script src="<?php echo e(Neo::asset('js/dom.min.js')); ?>"></script>

<?php if($type == 'admin'): ?>
    <script src="<?php echo e(Neo::asset('js/neo/plugins/index.min.js')); ?>"></script>
    <script src="<?php echo e(Neo::asset('js/neo/validator.min.js')); ?>"></script>
    <script src="<?php echo e(Neo::asset('js/trans.min.js')); ?>"></script>
    <script src="<?php echo e(Neo::asset('js/index.min.js')); ?>"></script>
    <script>
        Neo.load(function() {
            Neo.getComponent("neo-printer").globals = [
                "<?php echo e(Neo::asset('css/index.min.css')); ?>",
                "<?php echo e(Neo::asset('css/print.min.css')); ?>",
            ];
        });
    </script>
<?php endif; ?>

<?php if($type == 'guest'): ?>
    <script src="<?php echo e(Neo::asset('js/neo/plugins/guest.min.js')); ?>"></script>
    <script src="<?php echo e(Neo::asset('js/guest.min.js')); ?>"></script>
<?php endif; ?>

<?php if(Session::has('message')): ?>
    <?php
        $messages = is_array(Session::get('message')) ? Session::get('message') : [Session::get('message')];
    ?>
    <script>
        Neo.load(function() {
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                Neo.Toaster.show({
                    message: "<?php echo e($message); ?>",
                    theme: "<?php echo e(Session::get('type')); ?>",
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php endif; ?>
<?php /**PATH P:\php\manar\resources\views/shared/base/scripts.blade.php ENDPATH**/ ?>