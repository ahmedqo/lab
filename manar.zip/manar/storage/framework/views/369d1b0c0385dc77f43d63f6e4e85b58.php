
<?php $__env->startSection('title', __('Edit post') . ' #' . $data->id); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="image" content="<?php echo e($data->image->link); ?>">
    <meta name="routes" content='<?php echo json_encode([
        'index' => route('actions.images.index'),
        'store' => route('actions.images.store'),
        'clear' => route('actions.images.clear'),
        'csrf' => csrf_token(),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.blogs.patch', $data->id)); ?>" method="POST" enctype="multipart/form-data"
        class="w-full">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <neo-stepper step="step-1">
            <neo-stepper-item step="step-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-dropzone name="image" value="<?php echo e(old('image')); ?>" class="w-full"></neo-dropzone>
                
            </neo-stepper-item>
            <neo-stepper-item toggle step="step-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                <div class="flex items-end w-full isolate overflow-hidden">
                    <?php $__currentLoopData = Neo::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" data-target="<?php echo e($lang); ?>"
                            class="flex items-center justify-center px-6 py-2 rounded-t-x-thin font-x-thin text-sm lg:text-base outline-none border border-transparent <?php echo e($loop->index ? 'text-x-black border-b-x-shade' : 'bg-x-prime text-x-white'); ?> hover:bg-x-prime/20 hover:!text-x-black focus-within:bg-x-prime/20 focus-within:!text-x-black">
                            <?php echo e(ucfirst(__($language))); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full h-px bg-x-shade -mt-px z-[-1]"></div>
                </div>
                <?php $__currentLoopData = Neo::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-for="<?php echo e($lang); ?>"
                        class="<?php echo e($loop->index ? 'hidden' : 'grid'); ?> grid-cols-1 grid-rows-1 gap-6">
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The title :lang field is required', ['lang' => $language])); ?>"}'
                            label="<?php echo e(__('Title')); ?> (*)" name="title_<?php echo e($lang); ?>"
                            value="<?php echo e(old('title_' . $lang, $data->{'title_' . $lang})); ?>" class="w-full"></neo-textbox>
                        <div class="flex flex-col gap-1">
                            <label class="text-x-black font-x-thin text-base">
                                <?php echo e(__('Content')); ?>

                            </label>
                            <textarea data-type="rich" rules="required"
                                errors='{"required": "<?php echo e(__('The content :lang field is required', ['lang' => $language])); ?>"}'
                                name="content_<?php echo e($lang); ?>"><?php echo old('content_' . $lang, $data->{'content_' . $lang}); ?></textarea>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </neo-stepper-item>
            <neo-stepper-item toggle step="step-3" class="grid grid-cols-1 grid-rows-1 gap-6">
                <div class="flex items-end w-full isolate overflow-hidden">
                    <?php $__currentLoopData = Neo::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" data-target="<?php echo e($lang); ?>"
                            class="flex items-center justify-center px-6 py-2 rounded-t-x-thin font-x-thin text-sm lg:text-base outline-none border border-transparent <?php echo e($loop->index ? 'text-x-black border-b-x-shade' : 'bg-x-prime text-x-white'); ?> hover:bg-x-prime/20 hover:!text-x-black focus-within:bg-x-prime/20 focus-within:!text-x-black">
                            <?php echo e(ucfirst(__($language))); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full h-px bg-x-shade -mt-px z-[-1]"></div>
                </div>
                <?php $__currentLoopData = Neo::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-for="<?php echo e($lang); ?>"
                        class="<?php echo e($loop->index ? 'hidden' : 'grid'); ?> grid-cols-1 grid-rows-1 gap-6">
                        <neo-textbox label="<?php echo e(__('Meta title')); ?>" name="meta_title_<?php echo e($lang); ?>"
                            value="<?php echo e(old('meta_title_' . $lang, $data->{'meta_title_' . $lang})); ?>"
                            class="w-full"></neo-textbox>
                        <neo-textarea label="<?php echo e(__('Meta description')); ?>" name="meta_description_<?php echo e($lang); ?>"
                            value="<?php echo e(old('meta_description_' . $lang, $data->{'meta_description_' . $lang})); ?>"
                            rows="5" class="w-full"></neo-textarea>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </neo-stepper-item>
            <div slot="lower" class="w-full flex flex-wrap gap-6">
                <neo-button outline type="button" id="prev" style="display: none"
                    class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span><?php echo e(__('Prev')); ?></span>
                </neo-button>
                <neo-button id="save" style="display: none"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
                <neo-button outline type="button" id="next"
                    class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span><?php echo e(__('Next')); ?></span>
                </neo-button>
            </div>
        </neo-stepper>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(Neo::asset('js/editor/jodit.min.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(Neo::asset('js/editor/jodit.min.js')); ?>"></script>
    <script src="<?php echo e(Neo::asset('js/blog/share.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\manar\resources\views/blog/patch.blade.php ENDPATH**/ ?>