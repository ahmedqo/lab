<?php

namespace App\Http\Middleware;

use App\Functions\Neo;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;

class Trans
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $locale = explode('/', $request->path())[0];

        if (in_array($locale, Neo::$Locales)) {
            App::setLocale($locale);
            Session::put('locale', $locale);
        } else {
            App::setLocale(env('BASE_LOCALE'));
            Session::put('locale', env('BASE_LOCALE'));
        }

        return $next($request);
    }
}
