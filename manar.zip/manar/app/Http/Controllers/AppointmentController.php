<?php

namespace App\Http\Controllers;

use App\Functions\Neo;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redirect;
use App\Functions\Mail as Mailler;
use Illuminate\Mail\Mailables\Address;
use Carbon\Carbon;

class AppointmentController extends Controller
{
    public function patch_view($id)
    {
        $cache = Appointment::addCache("appointments/$id", ["appointments:$id", 'appointment']);

        $data = Cache::rememberForever($cache, function () use ($id) {
            return Appointment::findorfail($id);
        });

        return view('appointment.patch', compact('data'));
    }

    public function index_action()
    {
        return  Appointment::orderBy('id', 'DESC')->get()->map(function ($item) {
            return [
                'start' => $item->date . 'T' .  $item->time,
                'end' => $item->date . 'T' . Carbon::parse($item->time)->addMinutes(30)->format('H:i:s'),
                'title' => $item->patient,
                'color' => $item->status == 'canceled' ? '#fca5a5' : ($item->status == 'pending' ? '#fcd34d' : '#6ee7b7'),
                'data' => [
                    'url' => route('views.appointments.patch', $item->id)
                ]
            ];
        })->all();
    }

    public function search_action(Request $Request, $date)
    {
        $data = Appointment::where('date', $date)->pluck('time')->toArray();
        $slots = array_values(array_diff(Neo::slotsList($date), $data));

        return response()->json([
            'data' => $slots
        ]);
    }

    public function store_action(Request $Request)
    {
        $validator = Validator::make($Request->all(), [
            'patient' => ['required', 'string'],
            'phone' => ['required', 'string'],
            'time' => ['required', 'string'],
            'date' => ['required', 'date'],
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withInput()->with([
                'message' => $validator->errors()->all(),
                'type' => 'error'
            ]);
        }

        $Appointment = Appointment::create($Request->merge([
            'status' => 'pending'
        ])->all());

        Mailler::rdv([
            'to' => [new Address(env('MAIL_CONTACT_ADDRESS'), env('MAIL_NAME')), new Address('ahmedqo1995@gmail.com', env('MAIL_NAME'))],
            'Appointment' => $Appointment
        ]);

        return Redirect::back()->with([
            'message' => __('Votre rendez-vous a été pris avec succès. Merci d\'avoir choisi notre cabinet, nous sommes impatients de vous accueillir bientôt.'),
            'type' => 'success'
        ]);
    }

    public function patch_action(Request $Request, $id)
    {
        $validator = Validator::make($Request->all(), [
            'patient' => ['required', 'string'],
            'phone' => ['required', 'string'],
            'time' => ['required', 'string'],
            'date' => ['required', 'date'],
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withInput()->with([
                'message' => $validator->errors()->all(),
                'type' => 'error'
            ]);
        }

        Appointment::findorfail($id)->update($Request->all());

        return Redirect::back()->with([
            'message' => __('Updated successfully'),
            'type' => 'success'
        ]);
    }
}
