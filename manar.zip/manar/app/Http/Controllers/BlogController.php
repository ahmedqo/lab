<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class BlogController extends Controller
{
    public function index_view()
    {
        return view('blog.index');
    }

    public function store_view()
    {
        return view('blog.store');
    }

    public function patch_view($id)
    {
        $cache = Blog::addCache("blogs/$id", ["blogs:$id", 'blog']);

        $data = Cache::rememberForever($cache, function () use ($id) {
            return Blog::with([
                'Image:target_type,target_id,storage',
            ])->select(
                array_diff(Schema::getColumnListing('blogs'), ['created_at', 'updated_at'])
            )->findorfail($id);
        });

        return view('blog.patch', compact('data'));
    }

    public function search_action(Request $Request)
    {
        $search = $Request->search ? "/search/$Request->search" : '';
        $cursor = $Request->cursor ? "/cursor/$Request->cursor" : '';
        $cache = Blog::addCache("blogs$search$cursor", ['blogs']);

        $data = Cache::rememberForever($cache, function () use ($Request) {
            $data = Blog::with([
                'Image:target_type,target_id,storage',
            ])->select(
                'id',
                'title_fr',
                'title_ar',
            )->orderBy('id', 'DESC');
            if ($Request->search) {
                $data = $data->search(urldecode($Request->search));
            }
            return $data->cursorPaginate(50);
        });

        return response()->json($data);
    }

    public function store_action(Request $Request)
    {
        $validator = Validator::make($Request->all(), [
            'title_fr' => ['required', 'unique:blogs,title_fr'],
            'title_ar' => ['required', 'unique:blogs,title_ar'],
            'content_fr' => ['required', 'string'],
            'content_ar' => ['required', 'string'],
            'image' => ['required', 'image'],
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withInput()->with([
                'message' => $validator->errors()->all(),
                'type' => 'error'
            ]);
        }

        Blog::create($Request->merge([
            'treatments' => implode('|', $Request->treatments ?? []),
            'services' => implode('|', $Request->services ?? []),
            'read_time' => ceil(str_word_count(strip_tags($Request->content)) / 225)
        ])->all());

        return Redirect::back()->with([
            'message' => __('Created successfully'),
            'type' => 'success'
        ]);
    }

    public function patch_action(Request $Request, $id)
    {
        $validator = Validator::make($Request->all(), [
            'title_fr' => ['required', 'unique:blogs,title_fr,' . $id],
            'title_ar' => ['required', 'unique:blogs,title_ar,' . $id],
            'content_fr' => ['required', 'string'],
            'content_ar' => ['required', 'string'],
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withInput()->with([
                'message' => $validator->errors()->all(),
                'type' => 'error'
            ]);
        }

        Blog::findorfail($id)->update($Request->merge([
            'treatments' => implode('|', $Request->treatments ?? []),
            'services' => implode('|', $Request->services ?? []),
            'read_time' => ceil(str_word_count(strip_tags($Request->content)) / 225)
        ])->all());

        return Redirect::back()->with([
            'message' => __('Updated successfully'),
            'type' => 'success'
        ]);
    }

    public function clear_action($id)
    {
        Blog::findorfail($id)->delete();

        return Redirect::route('views.blogs.index')->with([
            'message' => __('Deleted successfully'),
            'type' => 'success'
        ]);
    }
}
