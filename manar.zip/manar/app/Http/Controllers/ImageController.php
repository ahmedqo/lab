<?php

namespace App\Http\Controllers;

use App\Models\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ImageController extends Controller
{
    public function index_action()
    {
        $cache = Image::addCache('image', ['images']);

        $data = Cache::rememberForever($cache, function () {
            return Image::where('target_type', 'App\\Models\\Self')->get()->map(function ($Carry, $i) {
                return [
                    'file'  => $Carry->storage,
                    'thumb' => $Carry->storage,
                    'name' => 'Image ' . $i + 1,
                    'type'  => 'image'
                ];
            });
        });

        return response()->json([
            'success' => true,
            'time' => now(),
            'data' => [
                'sources' => [
                    [
                        'baseurl' => url(''),
                        'path' => '/storage/' . Image::$STORAGE,
                        'files' => $data,
                        'folders' => [],
                        'name' => 'default'
                    ]
                ],
                'code' => 220
            ]
        ]);
    }

    public function store_action(Request $Request)
    {
        foreach ($Request->file('files') as $File) {
            Image::$FILE = $File;
            Image::create([
                'target_type' => 'App\\Models\\Self',
                'target_id' => 0,
            ]);
        }
        Image::delCache(["image"], ['images']);

        return response()->json([
            'success' => true,
            'files'   => [],
        ]);
    }

    public function clear_action(Request $Request)
    {
        parse_str($Request->getContent(), $data);

        Image::where('storage', $data['name'])->delete();
        Image::delCache(["image"], ['images']);

        return response()->json([
            'success' => true,
            'time' => now(),
            'data' => [
                'sources' => [],
                'code' => 220
            ],
        ]);
    }
}
