<?php

namespace App\Models;

use App\Traits\HasCache;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model
{
    use HasFactory, HasCache;

    protected $fillable = [
        'patient',
        'phone',
        'date',
        'time',
        'message',
        'status',
    ];

    protected static function booted()
    {
        foreach (['saved', 'deleted'] as $event) {
            self::{$event}(function ($Self) {
                self::delCache(
                    ["appointments/$Self->id"],
                    ['appointments']
                );
            });
        }
    }
}
