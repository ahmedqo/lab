<?php

namespace App\Models;

use App\Traits\HasCache;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Support\Facades\Storage;

class Image extends Model
{
    use HasFactory, HasCache;

    protected $fillable = [
        'target_id',
        'target_type',
        'storage',
        'width',
        'height'
    ];

    public static $STORAGE = 'IMAGES';
    public static $FILE = null;

    protected static function booted()
    {
        self::creating(function ($Self) {
            [$Self->width, $Self->height] = getimagesize(self::$FILE->getPathname());
            $name =  Storage::disk('public')->put(self::$STORAGE,  self::$FILE);
            $Self->storage = basename($name);
        });

        self::created(function ($Self) {
            self::$FILE = null;
        });

        self::deleted(function ($Self) {
            Storage::disk('public')->delete(implode('/', [self::$STORAGE, $Self->storage]));
        });
    }

    public function getLinkAttribute()
    {
        return url(Storage::url(implode('/', [self::$STORAGE, $this->storage])), [], false);
    }

    public function Target(): MorphTo
    {
        return $this->morphTo(__FUNCTION__, 'target_type', 'target_id');
    }
}
