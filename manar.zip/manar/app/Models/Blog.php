<?php

namespace App\Models;

use App\Functions\Neo;
use App\Traits\HasCache;
use App\Traits\HasSearch;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Support\Str;

class Blog extends Model
{
    use HasFactory, HasSearch, HasCache;

    protected $fillable = [
        'slug',
        'read_time',
        'title_fr',
        'content_fr',
        'meta_title_fr',
        'meta_description_fr',
        'title_ar',
        'content_ar',
        'meta_title_ar',
        'meta_description_ar',
        'treatments',
        'services',
    ];

    protected $searchable = [
        'title_fr',
        'title_ar',
    ];

    protected static function booted()
    {
        self::saving(function ($Self) {
            $Self->slug = Str::slug($Self->title_fr);
        });

        self::saved(function ($Self) {
            Image::$FILE = request()->file('image');
            if (isset(Image::$FILE)) {
                if ($Self->Image)  $Self->Image->delete();
                $Self->Image()->create();
            }
        });

        self::deleted(function ($Self) {
            $Self->Image->delete();
        });

        foreach (['saved', 'deleted'] as $event) {
            self::{$event}(function ($Self) {
                self::delCache(
                    ["blogs/$Self->id"],
                    ['blogs', "blogs:$Self->slug"]
                );
            });
        }
    }

    public function getTitleAttribute()
    {
        return $this->{'title_' . Neo::locale()};
    }

    public function getContentAttribute()
    {
        return $this->{'content_' . Neo::locale()};
    }

    public function getMetaTitleAttribute()
    {
        return $this->{'meta_title_' . Neo::locale()};
    }

    public function getMetaDescriptionAttribute()
    {
        return $this->{'meta_description_' . Neo::locale()};
    }

    public function Image(): MorphOne
    {
        return $this->morphOne(Image::class, 'target');
    }
}
