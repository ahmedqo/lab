@extends('shared.core.base')
@section('title', __('Blog posts'))

@section('meta')
    <meta name="routes" content='{!! json_encode([
        'search' => route('actions.blogs.search'),
        'patch' => route('views.blogs.patch', 'XXX'),
        'clear' => route('actions.blogs.clear', 'XXX'),
        'csrf' => csrf_token(),
    ]) !!}' />
@endsection

@section('content')
    <div class="bg-x-white rounded-x-huge shadow-x-core">
        <neo-datasheet caption="{{ __('Blog posts') }}" search printer="#datasheet-print" download visibility>
            <neo-tooltip slot="end" caption="{{ __('Create') }}">
                <a href="{{ route('views.blogs.store') }}"
                    class="flex w-8 h-8 items-center justify-center text-x-white outline-none rounded-x-thin bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <svg class="block w-6 h-6 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
                        <path
                            d="M479.825-185q-18.45 0-31.637-12.625Q435-210.25 435-231v-203H230q-18.375 0-31.688-13.56Q185-461.119 185-479.86q0-20.14 13.312-32.64Q211.625-525 230-525h205v-205q0-19.775 13.358-32.388Q461.716-775 480.158-775t32.142 12.612Q526-749.775 526-730v205h204q18.8 0 32.4 12.675 13.6 12.676 13.6 32.316 0 19.641-13.6 32.825Q748.8-434 730-434H526v203q0 20.75-13.65 33.375Q498.699-185 479.825-185Z" />
                    </svg>
                </a>
            </neo-tooltip>
        </neo-datasheet>
        <neo-overlay id="datasheet-modal" caption="{{ __('Cofirm deletion') }}">
            <div class="flex flex-col gap-6 p-6">
                <div class="flex flex-col gap-3">
                    <p class="text-center text-x-black text-lg font-x-huge">
                        {{ __('Are you sure you want to delete this post?') }}
                    </p>
                    <p class="text-center text-x-black text-base font-x-thin">
                        {{ __('This action is permanent and cannot be undone.') }}
                    </p>
                </div>
                <div class="w-max flex flex-wrap mx-auto gap-4">
                    <button id="datasheet-cancel"
                        class="px-4 py-2 text-x-black text-base font-x-thin rounded-x-thin outline-none hover:bg-x-light focus-within:bg-x-light">
                        {{ __('cancel') }}
                    </button>
                    <button id="datasheet-submit"
                        class="px-4 py-2 text-x-white text-base font-x-thin rounded-x-thin outline-none bg-red-500 hover:bg-red-400 focus-within:bg-red-400">
                        {{ __('Delete') }}
                    </button>
                </div>
            </div>
        </neo-overlay>
        <neo-printer id="datasheet-print">
            <style slot="styles">
                [datasheet_wrapper] {
                    padding: 1rem;
                }
            </style>
            @include('shared.page.print')
        </neo-printer>
    </div>
@endsection

@section('scripts')
    <script src="{{ Neo::asset('js/blog/index.min.js') }}"></script>
@endsection
