@extends('shared.core.base')
@section('title', __('Edit post') . ' #' . $data->id)

@section('meta')
    <meta name="image" content="{{ $data->image->link }}">
    <meta name="routes" content='{!! json_encode([
        'index' => route('actions.images.index'),
        'store' => route('actions.images.store'),
        'clear' => route('actions.images.clear'),
        'csrf' => csrf_token(),
    ]) !!}' />
@endsection

@section('content')
    <form validate action="{{ route('actions.blogs.patch', $data->id) }}" method="POST" enctype="multipart/form-data"
        class="w-full">
        @csrf
        @method('patch')
        <neo-stepper step="step-1">
            <neo-stepper-item step="step-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-dropzone name="image" value="{{ old('image') }}" class="w-full"></neo-dropzone>
                {{-- <neo-select label="{{ __('Treatments') }}" name="treatments[]" class="w-full">
                    <neo-select-popup>
                        @foreach (Neo::extraList('treatments') as $treatment)
                            <neo-select-option value="{{ $treatment }}"
                                {{ in_array($treatment, old('treatments', explode('|', $data->treatments))) ? 'active' : '' }}>
                                {{ ucfirst(__($treatment)) }}
                            </neo-select-option>
                        @endforeach
                    </neo-select-popup>
                </neo-select>
                <neo-select label="{{ __('Services') }}" name="services[]" class="w-full">
                    <neo-select-popup>
                        @foreach (Neo::extraList('services') as $service)
                            <neo-select-option value="{{ $service }}"
                                {{ in_array($service, old('services', explode('|', $data->services))) ? 'active' : '' }}>
                                {{ ucfirst(__($service)) }}
                            </neo-select-option>
                        @endforeach
                    </neo-select-popup>
                </neo-select> --}}
            </neo-stepper-item>
            <neo-stepper-item toggle step="step-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                <div class="flex items-end w-full isolate overflow-hidden">
                    @foreach (Neo::languagesList() as $lang => $language)
                        <button type="button" data-target="{{ $lang }}"
                            class="flex items-center justify-center px-6 py-2 rounded-t-x-thin font-x-thin text-sm lg:text-base outline-none border border-transparent {{ $loop->index ? 'text-x-black border-b-x-shade' : 'bg-x-prime text-x-white' }} hover:bg-x-prime/20 hover:!text-x-black focus-within:bg-x-prime/20 focus-within:!text-x-black">
                            {{ ucfirst(__($language)) }}
                        </button>
                    @endforeach
                    <div class="w-full h-px bg-x-shade -mt-px z-[-1]"></div>
                </div>
                @foreach (Neo::languagesList() as $lang => $language)
                    <div data-for="{{ $lang }}"
                        class="{{ $loop->index ? 'hidden' : 'grid' }} grid-cols-1 grid-rows-1 gap-6">
                        <neo-textbox rules="required"
                            errors='{"required": "{{ __('The title :lang field is required', ['lang' => $language]) }}"}'
                            label="{{ __('Title') }} (*)" name="title_{{ $lang }}"
                            value="{{ old('title_' . $lang, $data->{'title_' . $lang}) }}" class="w-full"></neo-textbox>
                        <div class="flex flex-col gap-1">
                            <label class="text-x-black font-x-thin text-base">
                                {{ __('Content') }}
                            </label>
                            <textarea data-type="rich" rules="required"
                                errors='{"required": "{{ __('The content :lang field is required', ['lang' => $language]) }}"}'
                                name="content_{{ $lang }}">{!! old('content_' . $lang, $data->{'content_' . $lang}) !!}</textarea>
                        </div>
                    </div>
                @endforeach
            </neo-stepper-item>
            <neo-stepper-item toggle step="step-3" class="grid grid-cols-1 grid-rows-1 gap-6">
                <div class="flex items-end w-full isolate overflow-hidden">
                    @foreach (Neo::languagesList() as $lang => $language)
                        <button type="button" data-target="{{ $lang }}"
                            class="flex items-center justify-center px-6 py-2 rounded-t-x-thin font-x-thin text-sm lg:text-base outline-none border border-transparent {{ $loop->index ? 'text-x-black border-b-x-shade' : 'bg-x-prime text-x-white' }} hover:bg-x-prime/20 hover:!text-x-black focus-within:bg-x-prime/20 focus-within:!text-x-black">
                            {{ ucfirst(__($language)) }}
                        </button>
                    @endforeach
                    <div class="w-full h-px bg-x-shade -mt-px z-[-1]"></div>
                </div>
                @foreach (Neo::languagesList() as $lang => $language)
                    <div data-for="{{ $lang }}"
                        class="{{ $loop->index ? 'hidden' : 'grid' }} grid-cols-1 grid-rows-1 gap-6">
                        <neo-textbox label="{{ __('Meta title') }}" name="meta_title_{{ $lang }}"
                            value="{{ old('meta_title_' . $lang, $data->{'meta_title_' . $lang}) }}"
                            class="w-full"></neo-textbox>
                        <neo-textarea label="{{ __('Meta description') }}" name="meta_description_{{ $lang }}"
                            value="{{ old('meta_description_' . $lang, $data->{'meta_description_' . $lang}) }}"
                            rows="5" class="w-full"></neo-textarea>
                    </div>
                @endforeach
            </neo-stepper-item>
            <div slot="lower" class="w-full flex flex-wrap gap-6">
                <neo-button outline type="button" id="prev" style="display: none"
                    class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Prev') }}</span>
                </neo-button>
                <neo-button id="save" style="display: none"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span>{{ __('Save') }}</span>
                </neo-button>
                <neo-button outline type="button" id="next"
                    class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Next') }}</span>
                </neo-button>
            </div>
        </neo-stepper>
    </form>
@endsection

@section('scripts')
    <link rel="stylesheet" href="{{ Neo::asset('js/editor/jodit.min.css') }}" />
    <script type="text/javascript" src="{{ Neo::asset('js/editor/jodit.min.js') }}"></script>
    <script src="{{ Neo::asset('js/blog/share.min.js') }}"></script>
@endsection
