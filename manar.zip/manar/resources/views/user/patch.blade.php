@extends('shared.core.base')
@section('title', __('Edit user') . ' #' . $data->id)

@section('content')
    <form validate action="{{ route('actions.users.patch', $data->id) }}" method="POST" class="w-full">
        @csrf
        @method('patch')
        <neo-stepper step="step-1">
            <neo-stepper-item step="step-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-textbox rules="required" errors='{"required": "{{ __('The first name field is required') }}"}'
                    label="{{ __('First name') }} (*)" name="first_name" value="{{ old('first_name', $data->first_name) }}"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required" errors='{"required": "{{ __('The last name field is required') }}"}'
                    label="{{ __('Last name') }} (*)" name="last_name" value="{{ old('last_name', $data->last_name) }}"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required|email"
                    errors='{"required": "{{ __('The email field is required') }}", "email": "{{ __('The email field must be a valid email') }}"}'
                    type="email" label="{{ __('Email') }} (*)" name="email" value="{{ old('email', $data->email) }}"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required|phone"
                    errors='{"required": "{{ __('The phone field is required') }}", "phone": "{{ __('The phone field must be a valid phone number') }}"}'
                    type="tel" label="{{ __('Phone') }} (*)" name="phone" value="{{ old('phone', $data->phone) }}"
                    class="w-full"></neo-textbox>
            </neo-stepper-item>
            <neo-stepper-item step="step-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-select label="{{ __('Gender') }}" name="gender" class="w-full">
                    <neo-select-popup>
                        @foreach (Neo::genderList() as $gender)
                            <neo-select-option value="{{ $gender }}"
                                {{ $gender == old('gender', $data->gender) ? 'active' : '' }}>
                                {{ ucfirst(__($gender)) }}
                            </neo-select-option>
                        @endforeach
                    </neo-select-popup>
                </neo-select>
                <neo-datepicker {{ !Neo::locale('ar') ? 'full-day=3' : '' }} label="{{ __('Birth date') }}"
                    name="birth_date" format="{{ Neo::formatsList(Neo::preference('date_format'), 0) }}"
                    value="{{ old('birth_date', $data->birth_date) }}" class="w-full"></neo-datepicker>
                <neo-textarea label="{{ __('Address') }}" name="address" value="{{ old('address', $data->address) }}"
                    rows="4" class="w-full"></neo-textarea>
            </neo-stepper-item>
            <div slot="lower" class="w-full flex flex-wrap gap-6">
                <neo-button outline type="button" id="prev" style="display: none"
                    class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Prev') }}</span>
                </neo-button>
                <neo-button id="save" style="display: none"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span>{{ __('Save') }}</span>
                </neo-button>
                <neo-button outline type="button" id="next"
                    class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Next') }}</span>
                </neo-button>
            </div>
        </neo-stepper>
    </form>
@endsection
