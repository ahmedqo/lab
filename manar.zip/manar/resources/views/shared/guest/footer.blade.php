<footer class="bg-x-light py-6 lg:py-12">
    <div class="w-full container mx-auto p-4  grid grid-rows-1 grid-cols-1 lg:grid-cols-5 gap-10">
        <div class="flex flex-col gap-4">
            <h3 class="font-x-thin text-lg lg:leading-[1] text-start">
                {{ __('Product') }}
            </h3>
            <nav>
                <ul class="flex flex-col items-start gap-1">
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Features') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Pricing') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Free Trial') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Demo') }}
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="flex flex-col gap-4">
            <h3 class="font-x-thin text-lg lg:leading-[1] text-start">
                {{ __('Solutions') }}
            </h3>
            <nav>
                <ul class="flex flex-col items-start gap-1">
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Features') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Pricing') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Free Trial') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Demo') }}
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="flex flex-col gap-4">
            <h3 class="font-x-thin text-lg lg:leading-[1] text-start">
                {{ __('Resources') }}
            </h3>
            <nav>
                <ul class="flex flex-col items-start gap-1">
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Features') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Pricing') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Free Trial') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Demo') }}
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="flex flex-col gap-4">
            <h3 class="font-x-thin text-lg lg:leading-[1] text-start">
                {{ __('Company') }}
            </h3>
            <nav>
                <ul class="flex flex-col items-start gap-1">
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Features') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Pricing') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Free Trial') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Demo') }}
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="flex flex-col gap-4">
            <h3 class="font-x-thin text-lg lg:leading-[1] text-start">
                {{ __('Legal') }}
            </h3>
            <nav>
                <ul class="flex flex-col items-start gap-1">
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Features') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Pricing') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Free Trial') }}
                        </a>
                    </li>
                    <li>
                        <a href=""
                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                            {{ __('Demo') }}
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</footer>
