<header class="sticky top-0 z-[10]">
    <div class="container mx-auto p-4">
        <div class="w-full rounded-xl bg-x-white shadow-md border border-x-light px-4 py-2">
            <div class="flex gap-6 items-center">
                <div class="flex-[1]">
                    <a href="#" class="w-max flex items-center gap-2 flex-wrap">
                        <svg class="block w-8 h-8 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                            <path
                                d="M562.5-5q-134.5 0-227-95.61T243-331v-3Q133-355 60-439.69T-13-639v-261h162v-53h136v243H149v-54h-26v125q0 73.6 53.79 124.3t128.3 50.7q74.51 0 128.21-50.7T487-639v-125h-26v54H325v-243h136v53h162v261q0 111.65-69.5 195.33Q484-360 379-336v5q0 78 53.13 134 53.12 56 130.87 56 77 0 129.5-56T745-331v-60q-40-19-66-58.09-26-39.1-26-86.72 0-67.19 47-113.69T813.47-696q66.47 0 113 46.67Q973-602.67 973-536q0 47.81-25.5 86.91Q922-410 881-391v60q0 134.78-92 230.39Q697-5 562.5-5Zm251-499q13.97 0 22.74-9.26Q845-522.53 845-536q0-13.47-8.76-22.74-8.77-9.26-22.74-9.26-13.97 0-23.24 9.26Q781-549.47 781-536q0 13.47 9.26 22.74 9.27 9.26 23.24 9.26Zm-.5-32Z">
                            </path>
                        </svg>
                        <span class="text-2xl font-x-thin text-x-black"> Medicalink</span>
                    </a>
                </div>
                <div class="hidden lg:block flex-[3]">
                    <nav class="w-max mx-auto">
                        <ul class="flex flex-wrap items-center gap-6 w-max">
                            <li>
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('Home') }}
                                </a>
                            </li>
                            <li
                                class="group relative isolate after:content-[''] after:absolute after:inset-0 after:h-[3rem] after:-z-10">
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('Solutions') }}
                                </a>
                                <ul
                                    class="absolute top-12 left-1/2 -translate-x-1/2 w-max rounded-xl bg-x-white shadow-md border border-x-light px-8 py-3 hidden group-hover:flex group-focus-within:flex flex-col gap-2 items-center">
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Urologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Orthopédie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Gynécologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Gastro-entérologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Médecine Générale') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Chirurgie Dentaire') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li
                                class="group relative isolate after:content-[''] after:absolute after:inset-0 after:h-[3rem] after:-z-10">
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('Features') }}
                                </a>
                                <ul
                                    class="absolute top-12 left-1/2 -translate-x-1/2 w-max rounded-xl bg-x-white shadow-md border border-x-light px-8 py-3 hidden group-hover:flex group-focus-within:flex flex-col gap-2 items-center">
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Urologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Orthopédie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Gynécologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Gastro-entérologie') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Médecine Générale') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Chirurgie Dentaire') }}
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('Pricing') }}
                                </a>
                            </li>
                            <li>
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('About') }}
                                </a>
                            </li>
                            <li>
                                <a href=""
                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none">
                                    {{ __('Contact') }}
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="flex flex-wrap items-center justify-end gap-2 flex-[1]">
                    <a href="https://carsrental.ma/fleet"
                        class="group w-max flex p-1 outline-none rounded-full text-x-white bg-x-prime border-2 border-x-prime hover:bg-x-acent hover:border-x-acent focus-within:bg-x-acent focus-within:border-x-acent">
                        <div class="rounded-full text-lg font-x-thin px-4">
                            {{ __('Book Now') }}
                        </div>
                    </a>
                    <neo-dropdown class="lg:hidden" caption="{{ __('Menu') }}">
                        <button slot="trigger" name="menu-trigger"
                            class="flex w-10 h-10 items-center justify-center outline-none rounded-full hover:text-x-white hover:bg-x-prime focus-within:text-x-white focus-within:bg-x-prime">
                            <svg class="block w-6 h-6 pointer-events-none" fill="currentcolor" viewBox="0 -960 960 960">
                                <path
                                    d="M129-215q-20.75 0-33.375-12.675Q83-240.351 83-261.175 83-280 95.625-293T129-306h458q19.75 0 32.375 13.175 12.625 13.176 12.625 32Q632-240 619.375-227.5 606.75-215 587-215H129Zm0-221q-20.75 0-33.375-13.175Q83-462.351 83-482.175 83-502 95.625-514.5 108.25-527 129-527h339q18.75 0 31.875 12.675Q513-501.649 513-481.825 513-462 499.875-449 486.75-436 468-436H129Zm0-218q-20.75 0-33.375-13.175Q83-680.351 83-700.175 83-720 95.625-733 108.25-746 129-746h458q19.75 0 32.375 13.175 12.625 13.176 12.625 33Q632-680 619.375-667 606.75-654 587-654H129Zm605 173 114 113q13 14 12.5 33T847-304q-15 14-33.5 14T782-304L637-450q-14-13-14-31t14-32l145-146q13-13 31.5-13t33.5 13q13 14 12.5 33T847-594L734-481Z">
                                </path>
                            </svg>
                        </button>
                        <neo-dropdown-popup class="lg:hidden">
                            <nav>
                                <ul class="flex flex-col items-center gap-2 p-6">
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Home') }}
                                        </a>
                                    </li>
                                    <li
                                        class="group relative w-full isolate flex flex-col gap-2 items-center after:content-[''] after:absolute after:inset-0 after:h-[3rem] after:-z-10">
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Solutions') }}
                                        </a>
                                        <ul
                                            class="w-full rounded-xl bg-x-white border border-x-light px-8 py-3 hidden group-hover:flex group-focus-within:flex flex-col gap-2 items-center">
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Urologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Orthopédie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Gynécologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Gastro-entérologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Médecine Générale') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Chirurgie Dentaire') }}
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li
                                        class="group relative w-full isolate flex flex-col gap-2 items-center after:content-[''] after:absolute after:inset-0 after:h-[3rem] after:-z-10">
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Features') }}
                                        </a>
                                        <ul
                                            class="w-full rounded-xl bg-x-white border border-x-light px-8 py-3 hidden group-hover:flex group-focus-within:flex flex-col gap-2 items-center">
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Urologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Orthopédie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Gynécologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Gastro-entérologie') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Médecine Générale') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a href=""
                                                    class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                                    {{ __('Chirurgie Dentaire') }}
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Pricing') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('About') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href=""
                                            class="block w-max text-base font-x-thin text-x-black hover:text-x-prime focus-within:text-x-prime outline-none text-center">
                                            {{ __('Contact') }}
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </neo-dropdown-popup>
                    </neo-dropdown>
                </div>
            </div>
        </div>
    </div>
</header>
