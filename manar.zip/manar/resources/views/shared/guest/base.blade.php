<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ Neo::locale('ar') ? 'rtl' : 'ltr' }}" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    @yield('meta')
    @include('shared.base.styles')
    @yield('styles')
    <title>@yield('title')</title>
</head>

<body neo-close class="bg-x-white">
    <neo-wall>
        <img src="{{ Neo::logo() }}" alt="{{ env('APP_NAME') }} logo image" />
    </neo-wall>
    <neo-wrapper class="relative isolate">
        <div class="absolute w-full h-full inset-0 -z-20 opacity-40"
            style="background-image: url({{ Neo::asset('pattern/grid.svg') }})">
        </div>
        @include('shared.guest.header')
        <main class="flex flex-wrap">
            @yield('content')
        </main>
        @include('shared.guest.footer')
    </neo-wrapper>
    <neo-toaster horisontal="end" vertical="start"></neo-toaster>
    @include('shared.base.scripts', ['type' => 'admin'])
    @yield('scripts')
</body>

</html>
