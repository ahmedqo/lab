<div slot="footer" id="page-footer">
    <div class="banner"></div>
    <div class="content"></div>
</div>
