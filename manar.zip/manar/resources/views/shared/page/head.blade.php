<div slot="header" id="page-header">
    {{-- <div id="logo-row">
        <div class="space first"></div>
        <img id="logo" src="{{ Neo::logo(true) }}" />
        <div class="space last"></div>
    </div> --}}
    <div id="text-row">
        <div class="space first"></div>
        <h1 id="text">{{ strtoupper(__(env('APP_NAME'))) }}</h1>
        <div class="space last"></div>
    </div>
</div>
