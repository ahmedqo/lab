<script src="{{ Neo::asset('js/neo/index.min.js') }}"></script>
<script src="{{ Neo::asset('js/dom.min.js') }}"></script>

@if ($type == 'admin')
    <script src="{{ Neo::asset('js/neo/plugins/index.min.js') }}"></script>
    <script src="{{ Neo::asset('js/neo/validator.min.js') }}"></script>
    <script src="{{ Neo::asset('js/trans.min.js') }}"></script>
    <script src="{{ Neo::asset('js/index.min.js') }}"></script>
    <script>
        Neo.load(function() {
            Neo.getComponent("neo-printer").globals = [
                "{{ Neo::asset('css/index.min.css') }}",
                "{{ Neo::asset('css/print.min.css') }}",
            ];
        });
    </script>
@endif

@if ($type == 'guest')
    <script src="{{ Neo::asset('js/neo/plugins/guest.min.js') }}"></script>
    <script src="{{ Neo::asset('js/guest.min.js') }}"></script>
@endif

@if (Session::has('message'))
    @php
        $messages = is_array(Session::get('message')) ? Session::get('message') : [Session::get('message')];
    @endphp
    <script>
        Neo.load(function() {
            @foreach ($messages as $message)
                Neo.Toaster.show({
                    message: "{{ $message }}",
                    theme: "{{ Session::get('type') }}",
                });
            @endforeach
        });
    </script>
@endif
