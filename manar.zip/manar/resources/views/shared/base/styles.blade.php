<link rel="stylesheet" href="{{ Neo::asset('css/font.min.css') }}" media="print" onload="this.media='all';" />
<link rel="stylesheet" href="{{ Neo::asset('css/index.min.css') }}" />
