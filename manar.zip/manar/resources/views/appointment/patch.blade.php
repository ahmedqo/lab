@extends('shared.core.base')
@section('title', __('Edit appointment') . ' #' . $data->id)

@section('meta')
    <meta name="routes" content='{!! json_encode([
        'search' => route('actions.appointments.search', 'XXX'),
    ]) !!}' />
@endsection

@section('content')
    <form validate action="{{ route('actions.appointments.patch', $data->id) }}" method="POST" class="w-full">
        @csrf
        @method('patch')
        <neo-stepper step="step-1">
            <neo-stepper-item step="step-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-textbox rules="required" errors='{"required": "{{ __('The nom et prenom field is required') }}"}'
                    label="{{ __('Nom et prenom') }} (*)" name="patient" value="{{ old('patient', $data->patient) }}"
                    class="w-full"></neo-textbox>
                <neo-textbox rules="required|phone"
                    errors='{"required": "{{ __('The phone field is required') }}", "phone": "{{ __('The phone field must be a valid phone') }}"}'
                    type="tel" label="{{ __('Telephone') }} (*)" name="phone" value="{{ old('phone', $data->phone) }}"
                    class="w-full"></neo-textbox>
                <neo-select rules="required" errors='{"required": "{{ __('The status field is required') }}"}'
                    label="{{ __('Status') }} (*)" name="status" class="w-full">
                    <neo-select-popup>
                        @foreach (Neo::statusList() as $status)
                            <neo-select-option value="{{ $status }}"
                                {{ $status == old('status', $data->status) ? 'active' : '' }}>
                                {{ ucfirst(__($status)) }}
                            </neo-select-option>
                        @endforeach
                    </neo-select-popup>
                </neo-select>
            </neo-stepper-item>
            <neo-stepper-item step="step-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                <neo-datepicker id="date" {{ !Neo::locale('ar') ? 'full-day=3' : '' }} rules="required"
                    errors='{"required": "{{ __('The date field is required') }}", "date_after_or_equal": "{{ __('The date field must be equal or after today') }}"}'
                    label="{{ __('Date') }} (*)" name="date"
                    format="{{ Neo::formatsList(Neo::preference('date_format'), 0) }}"
                    value="{{ old('date', $data->date) }}" class="w-full"></neo-datepicker>
                <neo-select id="time" rules="required" errors='{"required": "{{ __('The time field is required') }}"}'
                    label="{{ __('Temps') }} (*)" name="time" class="w-full">
                    <neo-select-popup>
                        @foreach (Neo::slotsList() as $time)
                            <neo-select-option value="{{ $time }}"
                                {{ $time == old('time', $data->time) ? 'active' : '' }}>
                                {{ ucfirst(__($time)) }}
                            </neo-select-option>
                        @endforeach
                    </neo-select-popup>
                </neo-select>
                <neo-textarea label="{{ __('Message') }}" name="message" value="{{ old('message', $data->message) }}"
                    rows="4" class="w-full"></neo-textarea>
            </neo-stepper-item>
            <div slot="lower" class="w-full flex flex-wrap gap-6">
                <neo-button outline type="button" id="prev" style="display: none"
                    class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Prev') }}</span>
                </neo-button>
                <neo-button id="save" style="display: none"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span>{{ __('Save') }}</span>
                </neo-button>
                <neo-button outline type="button" id="next"
                    class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                    <span>{{ __('Next') }}</span>
                </neo-button>
            </div>
        </neo-stepper>
    </form>
@endsection

@section('scripts')
    <script src="{{ Neo::asset('js/book.min.js') }}"></script>
@endsection
