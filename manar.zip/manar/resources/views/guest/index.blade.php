@extends('shared.guest.base')
@section('title', __('Home Page'))

@section('meta')@endsection

@section('content')
    <div style="box-shadow: 0 0 5rem 10rem rgb(var(--prime) / .05)"
        class="w-px blur-[5rem] absolute left-1/2 -translate-x-1/2 aspect-square rounded-b-full bg-x-prime">
    </div>
    <section class="w-full relative isolate">
        <div class="absolute inset-0 w-full h-full overflow-hidden -z-10">
            <div
                class="absolute w-full h-1/3 inset-0 top-auto -z-10 bg-gradient-to-b from-transparent via-x-light to-x-light">
            </div>
        </div>
        <div class="w-full container mx-auto p-4 flex flex-col gap-12 pt-12 lg:pt-16">
            <div class="w-full flex flex-col items-center gap-6">
                <h1 class="max-w-[1000px] font-x-thin text-x-black text-4xl lg:text-6xl lg:leading-[1] text-center">
                    {!! __(
                        'Le <span class="text-x-prime">meilleur</span> logiciel de gestion de <span class="text-x-prime">cabinet</span> médical au <span class="text-x-prime">Maroc</span>, toutes <span class="text-x-prime">spécialités</span> confondu',
                    ) !!}
                </h1>
                <p class="max-w-[900px] text-x-black text-base lg:text-lg text-justify" style="text-align-last: center">
                    {{ __('Medicalink, c\'est le logiciel de gestion de cabinet médical qui change la donne au Maroc. Tout est là : rendez-vous, historique patient, ordonnances, radios, analyses, et même un lecteur DICOM en ligne inédit. Gérez votre cabinet comme vous l\'avez toujours rêvé avec une interface claire et des outils pensés pour vous. Infirmières, stock, cliniques externes, rappels WhatsApp : tout est connecté, tout est simple. Et chaque semaine, ça s\'améliore. Sérieusement.') }}
                </p>
            </div>
            <div class="max-w-[800px] w-max mx-auto flex flex-wrap items-center gap-4">
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-white bg-x-prime border-2 border-x-prime hover:bg-x-acent hover:border-x-acent focus-within:bg-x-acent focus-within:border-x-acent">
                    <div class="rounded-full text-lg font-x-thin px-6 py-1">
                        {{ __('Book Now') }}
                    </div>
                </a>
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-prime border-2 border-x-prime hover:text-x-white hover:border-x-x-black hover:border-y-x-black focus-within:text-x-white focus-within:border-x-x-black focus-within:border-y-x-black">
                    <div
                        class="rounded-full text-lg font-x-thin px-6 py-1 group-hover:bg-x-black group-focus-within:bg-x-black">
                        {{ __('Read More') }}
                    </div>
                </a>
            </div>
            <div class="max-w-[1000px] w-full mx-auto">
                <img src="https://rental-client.foxdigia.com/img/poster.png?v=0.51.1" alt=""
                    class="w-full rounded-2xl bg-x-light shadow-xl border border-x-light" />
            </div>
        </div>
    </section>
    <section class="bg-x-light w-full pt-8 lg:pt-20">
        <div class="container mx-auto p-4 grid grid-cols-1 grid-rows-1 lg:grid-cols-5 gap-10 items-center">
            <div class="flex flex-col gap-6 lg:col-span-2">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-start">
                    {{ __('Sécurité de niveau professionnel. Confiance garantie') }}
                </h2>
                <p class="text-x-black text-base text-start">
                    {{ __('Les données médicales de vos patients sont sensibles Medicalink les protège avec les mêmes standards que les grandes banques. Rien n\'est laissé au hasard.') }}
                </p>
            </div>
            <ul class="grid grid-cols-2 grid-rows-1 gap-6 lg:col-span-3">
                <li
                    class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6 relative isolate overflow-hidden">
                    <svg class="block w-44 h-44 lg:w-56 lg:h-56 text-x-prime/10 absolute right-0 bottom-0 -mr-12 -mb-12"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M248.31-56q-41.92 0-70.12-28.19Q150-112.39 150-154.31v-383.38q0-41.92 28.19-70.12Q206.39-636 248.31-636H272v-80q0-87.92 60.73-148.96Q393.46-926 480-926q86.54 0 147.27 61.04Q688-803.92 688-716v80h23.69q41.92 0 70.12 28.19Q810-579.61 810-537.69v383.38q0 41.92-28.19 70.12Q753.61-56 711.69-56H248.31Zm0-86h463.38q5.39 0 8.85-3.46t3.46-8.85v-383.38q0-5.39-3.46-8.85t-8.85-3.46H248.31q-5.39 0-8.85 3.46t-3.46 8.85v383.38q0 5.39 3.46 8.85t8.85 3.46Zm231.85-118q34.99 0 59.42-24.58Q564-309.17 564-344.16q0-34.99-24.58-59.42Q514.83-428 479.84-428q-34.99 0-59.42 24.58Q396-378.83 396-343.84q0 34.99 24.58 59.42Q445.17-260 480.16-260ZM358-636h244v-80q0-51-35.62-87.5t-86.5-36.5q-50.88 0-86.38 36.5Q358-767 358-716v80ZM236-142v-408 408Z" />
                    </svg>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Chiffrement AES-256') }}
                        </h3>
                        <p class="text-x-black text-base text-start">
                            {{ __('Toutes les données sont cryptées, au repos comme en transit comme les systèmes bancaires.') }}
                        </p>
                    </div>
                </li>
                <li
                    class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6 relative isolate overflow-hidden">
                    <svg class="-scale-x-100 block w-44 h-44 lg:w-56 lg:h-56 text-x-prime/10 absolute right-0 bottom-0 -mr-12 -mb-12"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M480-68q-85.41 0-160.59-32.48-75.19-32.48-130.82-88.11-55.63-55.63-88.11-130.82Q68-394.59 68-480t32.48-160.59q32.48-75.19 88.11-130.82 55.63-55.63 130.82-88.11Q394.59-892 480-892q20.57 0 40.31 1.92 19.75 1.93 39.3 6.93l-31.69 78.61q-12.46-2.61-24.92-3.73-12.46-1.11-24.92-.11-25.31 40.69-45.04 83.96-19.73 43.27-33.89 89.5h146.08v70H382.61q-3.76 21.03-5.46 42.27-1.69 21.23-1.69 42.65 0 21.42 1.69 42.65 1.7 21.24 5.46 42.27h194.84q3.7-21.53 5.4-40.5 1.69-18.96 1.69-28.27h70q0 9.31-1.69 28.27-1.7 18.97-4.47 40.5h146.77q6.08-20.53 8.47-40 2.38-19.46 2.38-28.77h86q0 77.93-32.46 149.43t-88.27 126.61q-55.81 55.12-130.89 87.46Q565.29-68 480-68ZM164.85-395.08h146.77q-2.77-21.53-4.47-42.27-1.69-20.73-1.69-42.65 0-21.92 1.69-42.65 1.7-20.74 4.47-42.27H164.85q-6.08 20.53-8.47 42.02-2.38 21.48-2.38 43.15 0 21.67 2.38 42.9 2.39 21.24 8.47 41.77Zm228.46 227q-25.69-37-42.04-76.5-16.35-39.5-24.73-80.5H194.46q30.07 59.9 81.61 100.88 51.55 40.97 117.24 56.12ZM194.08-634.92h132.46q9.15-41 25.69-80.31t41.08-76.69q-64.92 16.3-116.92 57.27-52.01 40.96-82.31 99.73ZM480-155.08q28.46-38.46 48.65-81.11 20.2-42.66 32.2-88.89h-161.7q12 46.23 32 89.27T480-155.08Zm86.69-13Q632-183.23 683.61-224.4q51.62-41.17 81.93-100.68H633.46q-10.31 40.62-26.27 80.12-15.96 39.5-40.5 76.88ZM682-563.85q-14 0-25.39-11.38-11.38-11.38-11.38-25.38v-133.23q0-14 11.38-25.39Q668-770.61 682-770.61h3.61v-40q0-34.47 24.25-57.93T768.79-892q34.67 0 59.13 23.46t24.46 57.93v40H856q14 0 25 11.38 11 11.39 11 25.39v133.23q0 14-11.39 25.38-11.38 11.38-25.38 11.38H682Zm47-206.76h80v-40q0-17-11.5-28.5t-28.5-11.5q-17 0-28.5 11.5t-11.5 28.5v40Z" />
                    </svg>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Hébergement 100% sécurisé au Maroc') }}
                        </h3>
                        <p class="text-x-black text-base text-start">
                            {{ __('Vos données restent dans le pays, protégées par les normes locales et les meilleures pratiques internationales.') }}
                        </p>
                    </div>
                </li>
                <li
                    class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6 relative isolate overflow-hidden">
                    <svg class="-scale-x-100 block w-44 h-44 lg:w-56 lg:h-56 text-x-prime/10 absolute right-0 bottom-0 -mr-12 -mb-12"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M151.08-151.08v-86h111.31Q208-288.31 179.5-348.04T151-477.46q0-112.08 68.04-203.42Q287.08-772.23 400-800.15v91.23q-71.77 24.3-117.39 88.3-45.61 64-45.61 143.16 0 46.46 17.61 88.35 17.62 41.88 59.85 84.19v-95.54h86v249.38H151.08ZM723-493.23q-2-36.77-18.69-78.42-16.69-41.66-58.77-83.04v95.15h-86v-249.38h249.38v86H697.61q55.47 48.77 83 110.88 27.54 62.12 28.39 118.81h-86ZM632.08-77.39q-13.85 0-24.66-10.8-10.8-10.81-10.8-24.66v-136.84q0-14.85 10.3-24.66 10.31-9.8 25.16-9.8H637v-40q0-34.46 24.46-57.93 24.46-23.46 58.92-23.46 34.47 0 58.93 23.46 24.46 23.47 24.46 57.93v40h4.92q14.85 0 24.77 9.8 9.92 9.81 9.92 24.66v136.84q0 13.85-10.8 24.66-10.81 10.8-24.66 10.8H632.08Zm48.3-206.76h80v-40q0-17-11.5-28.5t-28.5-11.5q-17 0-28.5 11.5t-11.5 28.5v40Z" />
                    </svg>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Accès multi-niveaux avec permissions') }}
                        </h3>
                        <p class="text-x-black text-base text-start">
                            {{ __('Chaque membre de votre équipe accède uniquement aux données qu\'il est autorisé à voir.') }}
                        </p>
                    </div>
                </li>
                <li
                    class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6 relative isolate overflow-hidden">
                    <svg class="block w-44 h-44 lg:w-56 lg:h-56 text-x-prime/10 absolute right-0 bottom-0 -mr-12 -mb-12"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M154-276v-404 404Zm36.62-160.62h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm-372-124h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm124 0h82.76v-82.76h-82.76v82.76Zm0 110.16q18.46-8.69 39.46-13.66 21-4.96 43.3-6.19v-49.07h-82.76v68.92Zm-370 137.84h250.24q5.14-22.92 16.6-43.61 11.46-20.69 26.54-39.15H316.62v82.76ZM166.31-190q-41.03 0-69.67-28.64T68-288.31v-379.38q0-41.03 28.64-69.67T166.31-766h627.38q41.03 0 69.67 28.64T892-667.69v236.15q-18.82-13.7-40.3-23-21.47-9.31-45.7-11.54v-201.61q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H166.31q-4.62 0-8.46 3.85-3.85 3.84-3.85 8.46v379.38q0 4.62 3.85 8.46 3.84 3.85 8.46 3.85H561v86H166.31ZM681.5-68q-15.12 0-25.5-11.89-10.39-11.88-10.39-26.94v-131.94q0-16 9.89-26 9.88-10 25.88-10h4.23v-40q0-34.46 24.25-57.92t58.93-23.46q34.67 0 59.13 23.46t24.46 57.92v40h4.23q16 0 25.7 10 9.69 10 9.69 26v131.94q0 15.06-10.19 26.94Q871.61-68 856.49-68H681.5ZM729-274.77h80v-40q0-17-11.5-28.5t-28.5-11.5q-17 0-28.5 11.5t-11.5 28.5v40Z" />
                    </svg>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Authentification double facteur (2FA)') }}
                        </h3>
                        <p class="text-x-black text-base text-start">
                            {{ __('Pour un accès ultra-sécurisé à votre compte, même depuis l\'extérieur du cabinet.') }}
                        </p>
                    </div>
                </li>
            </ul>
        </div>
    </section>
    <section class="bg-x-light w-full pt-8 lg:pt-20">
        <div
            class="container mx-auto p-4 grid grid-cols-1 grid-rows-1 lg:grid-cols-5 gap-10 items-center overflow-hidden lg:overflow-clip">
            <div class="w-full lg:col-span-3 flex flex-col gap-6">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-start">
                    {{ __('Pensé pour chaque spécialité médicale') }}
                </h2>
                <p class="text-x-black text-base text-start">
                    {{ __('Que vous soyez gastro-entérologue, rhumatologue, dentiste, généraliste ou gynécologue, Medicalink s\'adapte à votre manière de travailler. Notre logiciel de gestion de cabinet médical au Maroc propose des modules spécifiques pour chaque spécialité : gestion des dossiers patients, examens, ordonnances, et même des suivis complexes comme les sessions récurrentes. Oui, on pense aussi aux néphrologues et urologues avec des fonctionnalités cliniques vraiment utiles, pas juste du "générique" déguisé. C\'est votre spécialité, votre façon de soigner… et désormais, votre logiciel aussi.') }}
                </p>
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-prime border-2 border-x-prime hover:text-x-white hover:border-x-x-black hover:border-y-x-black focus-within:text-x-white focus-within:border-x-x-black focus-within:border-y-x-black">
                    <div
                        class="rounded-full text-lg font-x-thin px-6 py-1 group-hover:bg-x-black group-focus-within:bg-x-black">
                        {{ __('Explore All Specialities') }}
                    </div>
                </a>
            </div>
            <div class="w-full lg:col-span-2 lg:col-start-1 lg:row-start-1 -rotate-[10deg]">
                <div class="w-max flex flex-wrap gap-4 mx-auto">
                    <div class="w-max flex flex-col gap-4 items-end">
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-prime flex flex-col items-center justify-center shadow-md -me-8">
                            <svg class="w-10 h-10 text-x-white" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="M64-52v-292q0-54.42 38.29-92.21Q140.58-474 195-474h131q28 0 48-6.5t20-31.5q0-21.97-15.5-36.99Q363-564 340-564q-31.87 0-53.94-22.56Q264-609.13 264-641v-267h136v210q62 15 96 68.5T530-512q0 81-59 127.5T326-338H195q1.52 0 3.26-1.74Q200-341.48 200-343v291H64Zm352 0H280v-97q0-54.42 37.79-92.71Q355.58-280 411-280h177q72.6 0 122.3-53.7Q760-387.39 760-462v-48q0-71-38.5-126.5T617-692q-57 0-97-39.5T480-828v-80h136v81q121 9 200.5 101T896-510v48q0 131.43-88.78 224.72Q718.43-144 588-144H411q1.52 0 3.26-1.74Q416-147.48 416-149v97Zm-216 0v-291q0 1.52-1.74 3.26Q196.52-338 195-338h131q86 0 145-46.5T530-512q0-63-34-117t-96-69v-210 210q62 15 96 69t34 117q0 81-59 127.5T326-338H195q1.52 0 3.26-1.74Q200-341.48 200-343v291Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-white text-base text-center">
                                {{ __('Gastrologue') }}
                            </h3>
                        </div>
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-white flex flex-col items-center justify-center shadow-md">
                            <svg class="w-16 h-16 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="M480.47-520q-55.47 0-94.97-39.24-39.5-39.23-39.5-95Q346-710 385.24-749q39.23-39 95-39Q536-788 575-748.97q39 39.03 39 94.5t-39.03 94.97q-39.03 39.5-94.5 39.5Zm.03-104q12.5 0 21-9t8.5-21.5q0-12.5-8.62-21-8.63-8.5-21.38-8.5-12 0-21 8.62-9 8.63-9 21.38 0 12 9 21t21.5 9ZM226-266v-90q0-24 13-46.5t33-34.5q49-28 102.5-42.5t106-14.5q54.5 0 106.5 14t100.86 42.59q21.45 12.78 33.79 34.58Q734-381.04 734-355.95V-266H226Zm254-124q-26 0-53 5t-54 15h214q-27-10-54-15t-53-5Zm331-237q-36-73-78-115t-108-71l53-125q86 35.79 153.39 102.39Q898.78-769 936-680l-125 53Zm-664 1L22-680q37-88 103.5-154.5T280-938l53 125q-69 32-113 76t-73 111ZM281-23q-86-35.79-153.39-102.39Q60.22-192 23-281l125-53q30 68 73 110.5T334-149L281-23Zm397 2-53-125q67-30 113.5-76.5T811-332l125 53q-35.79 86-102.39 153.39Q767-58.22 678-21ZM480-654Zm0 284h107-214 107Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-prime text-base text-center">
                                {{ __('Médecine Générale') }}
                            </h3>
                        </div>
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-prime flex flex-col items-center justify-center shadow-md me-8">
                            <svg class="w-10 h-10 text-x-white" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="M480-58q-47 0-83-10.5T322-104l-112-70q-25-18-41.5-49T152-287q0-60 43-103.5T312-434q43 0 72.5 13.5T440-377q-2-2-4-3l-4-2 1-81q-59-2-104.5-13T252-504q-31-17-47-39.5T189-593q0-19 12.5-37.5T238-666q-4-9-6.5-19t-2.5-20q0-23 15.5-43.5T290-785q-1-4-1-6.5v-6.5q0-31 32-60.5t79-40.5v92q2-1 .5-.5T397-805q6 5 15 8.5t21 5.5v-144h94v144q12-2 21-5.5t15-8.5q-2-3-4-3h1v-91q46 11 78.5 40.5T671-798q0 2-1 13 30 16 45.5 36.5T731-705q0 10-2.5 20t-6.5 19q24 17 36.5 35.5T771-593q0 27-16 49.5T708-504q-31 17-76.5 28T527-463v81l-4 2q-2 1-5 3 24-30 58.5-43.5T648-434q73 0 116.5 44T808-286q0 35-16.5 65T747-173l-109 69q-40 25-74.5 35.5T480-58Zm0-102q32 0 54.5-6.5T584-190l109-69q6-4 9.5-11t3.5-16q0-19-16-32.5T648-332q-13 0-24.5 4T604-317q-28 23-59.5 35T480-270q-33 0-64.5-12T356-317q-8-7-19.5-11t-24.5-4q-26 0-42 13.5T254-287q0 8 3.5 16t9.5 12l110 68q26 17 48.5 24t54.5 7Zm-47-390v-33q-40-2-68-8t-53-16q-7 3-16 7.5T281-589q20 18 64 26.5t88 12.5ZM330-246q12 0 21-9t9-21q0-12-9-21t-21-9q-12 0-21 9t-9 21q0 12 9 21t21 9Zm103-426v-30q-25-2-42-6t-34-11l-20 8q-10 4-18 11 13 12 45.5 18.5T433-672Zm94 122q44-4 88-12.5t64-26.5q-5-5-15-10l-16-8q-25 10-53 16t-68 8v33Zm0-120q36-3 68-10.5t46-19.5q-8-7-18.5-11t-19.5-8q-17 6-34 10.5t-42 6.5v32Zm103 424q12 0 21-9t9-21q0-12-9-21t-21-9q-12 0-21 9t-9 21q0 12 9 21t21 9Zm-150 0Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-white text-base text-center">
                                {{ __('Orthopédie') }}
                            </h3>
                        </div>
                    </div>
                    <div class="w-max flex flex-col gap-4 mt-12">
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-white flex flex-col items-center justify-center shadow-md ms-8">
                            <svg class="w-10 h-10 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="M314 10v-67q-24-8-41-27.5t-21.28-45.48L237-218q-7-40 16-72t61-38v-40q-6-2-11.07-1.5-5.06.5-10.93.5-110 0-189-73T24-623v-71q0-115 77-198t191-83q61.08 0 104.54 42.03Q440-890.95 440-829.76q0 59.18-43.96 98.47T292-692h-25v-126h22.11q6.37 0 10.63-4.76Q304-827.53 304-834q0-6.47-4.01-10.74Q295.98-849 289-849q-58.94 0-98.97 42.59Q150-763.81 150-704v72q0 57.94 40.53 97.47T289-495q6.98 0 10.99-4.76T304-511q0-6.47-4.01-10.74Q295.98-526 289-526h-22v-126h25q59 0 103.5 38t44.5 95v190h80v-190q0-57 44.5-95T668-652h25v126h-22.11q-6.36 0-10.63 3.71-4.26 3.71-4.26 10.24t4.01 11.29Q664.03-496 671-496q57.94 0 98.47-39.53T810-632v-72q0-59.81-40.03-102.41Q729.94-849 671-849q-6.97 0-10.99 4.01Q656-840.97 656-834q0 6.47 4.01 11.24Q664.03-818 671-818h22v126h-25q-60.08 0-104.04-39.53Q520-771.05 520-830.24q0-61.18 43.46-102.97T668-975q114 0 191 83t77 198v71q0 108-79 181t-189 73q-5.87 0-10.93-.5Q652-370 646-368v40q38 6 61 38t16 72l-14.72 88.02Q704-104 687-84.5 670-65 646-57v67H520v-62h-80v62H314Zm0-213 4 25h271l5-25H314Zm0 0 4 25-4-25Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-prime text-base text-center">
                                {{ __('Urologie') }}
                            </h3>
                        </div>
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-prime flex flex-col items-center justify-center shadow-md">
                            <svg class="w-16 h-16 text-x-white" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="M680.21-890Q753-890 804-839t51 124q0 11.23-1 30.11-1 18.89-5 43.89l-55 402q-6 45-40.2 72.5-34.21 27.5-76.31 27.5-25.49 0-48.99-11.5Q605-162 590-184L483-339q-1 0-1.68-.5-.68-.5-2.54-.5-.78 0-3.78 3L371-186q-15 23-39.31 35-24.31 12-49.73 12-42.96 0-76.46-28-33.5-28-40.5-72l-54-402q-3-25-4.5-43.89Q105-703.77 105-715q0-73 51-124t123.55-51q39.48 0 62.97 9.5Q366-871 387-858q17.77 9.63 38.31 18.82 20.54 9.18 54.61 9.18 34.08 0 54.7-9.18 20.61-9.19 38.38-19.32 21.25-12.23 44.93-21.87 23.68-9.63 62.28-9.63ZM680-754q-10.02 0-19.51 4-9.49 4-20.49 11-32 17-67 31t-93 14q-58 0-93-14t-66-31q-12-7-21.5-11t-19.82-4q-15.62 0-27.65 11.53T241-715q1 12.58 1.5 25.79.5 13.21 2.45 26.65L296-293q-1-3-3.16-4.5t-5.04-1.5q-1.8 0-3.3.5-1.5.5-2.5 2.5l81-119q20-30 50.96-45.5 30.95-15.5 66-15.5Q515-476 546-460q31 16 51 46l80 118q-1-2-2.17-2.5-1.16-.5-2.72-.5-3.11 0-5.43 1.85-2.32 1.86-2.68 5.15l51.1-370.52Q717-681 718-694.71q1-13.71 1-20.29 0-16.09-11.46-27.54Q696.09-754 680-754ZM480-527Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-white text-base text-center">
                                {{ __('Chirurgie Dentaire') }}
                            </h3>
                        </div>
                        <div
                            class="w-max p-6 gap-3 rounded-x-huge aspect-square bg-x-white flex flex-col items-center justify-center shadow-md -ms-8">
                            <svg class="w-10 h-10 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                <path
                                    d="m357-66-43-83q-8.53-19.15-13.26-39.92-4.74-20.77-4.74-43.17 0-26.91 7.5-52.41Q311-310 327.27-332q5.73-7.78 8.73-17.78 3-10.01 3-19.77 0-13.42-5.5-24.9Q328-405.93 322-418q-9.43-20.9-16.72-43.56Q298-484.21 298-508v-152q0-23.33-17.79-39.67Q262.42-716 237-716q-17.43 0-30.72 8.5Q193-699 186-685q32 19 51.5 51.66Q257-600.69 257-560q0 59.58-41.04 101.29Q174.92-417 114.5-417q-60.42 0-101.96-41.71Q-29-500.42-29-560q0-44.35 23.5-78.68Q18-673 56-690q11-65 61.49-108.5T237-842q13 0 24.5 1.5T285-836q47.75-12.79 96.2-22.4 48.46-9.6 99.3-9.6 47.8 0 93.65 7.5Q620-853 663-833q14-4.67 28.5-6.83Q706-842 722-842q70.19 0 120.59 43.5Q893-755 905-690q38 17 61 51.32 23 34.33 23 78.68 0 59.58-41.78 101.29Q905.45-417 845.76-417q-59.68 0-101.22-41.71T703-560q0-40.69 19.5-73.34Q742-666 775-685q-8-14-22.19-22.5Q738.63-716 722-716q-25.42 0-42.71 16.33Q662-683.33 662-660v152q0 23.64-8.22 46.16Q645.57-439.32 636-418q-6.44 11.74-10.72 23.47-4.28 11.74-4.28 24.98 0 9.48 2.5 19.11Q626-340.8 632-333q15.93 23.24 23.96 48.77 8.04 25.52 8.04 52.1 0 22.13-5 43.13-5 21-15 40l-42 83-113-57 42-83q3-6.91 5-13 2-6.08 2-12.83 0-8.11-2.6-15.54-2.6-7.44-7.4-14.63-16-24-24.5-51.29T495-369q0-24 7.27-47.02Q509.54-439.03 520-462q5.65-11.29 10.82-22.16Q536-495.02 536-508v-152q0-18.84 2.55-34.98Q541.1-711.11 548-727q-16.75-3.33-33.7-4.17-16.95-.83-34.27-.83-17.33 0-33.69 1.53-16.36 1.54-33.34 5.47 5.66 14.82 8.33 31.41T424-660v152q0 13 4.5 23.5T438-463q10.83 22.3 18.92 46.15Q465-393 465-369.48q0 29.59-8.79 56.51-8.8 26.91-25.21 50.97-5 6.59-7 14.19-2 7.61-2 15.9 0 6.91 2 13.41t3.56 12.53L470-123 357-66ZM113.75-543q7.73 0 12.49-4.52 4.76-4.51 4.76-12.23 0-7.72-4.52-12.49-4.51-4.76-12.23-4.76-7.72 0-12.49 4.52Q97-567.97 97-560.25q0 7.72 4.52 12.49 4.51 4.76 12.23 4.76Zm732 0q7.72 0 12.49-4.52 4.76-4.51 4.76-12.23 0-7.72-4.52-12.49-4.51-4.76-12.23-4.76-7.72 0-12.49 4.52-4.76 4.51-4.76 12.23 0 7.72 4.52 12.49 4.51 4.76 12.23 4.76Zm.25-17Zm-732 0Z" />
                            </svg>
                            <h3 class="font-x-thin text-x-prime text-base text-center">
                                {{ __('Gynécologie') }}
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="w-full pt-8 lg:pt-20 relative isolate">
        <div class="absolute inset-0 w-full h-full -z-10">
            <div
                class="absolute w-full h-1/2 inset-0 bottom-auto -z-10 bg-gradient-to-b from-x-light via-transparent to-transparent">
            </div>
        </div>
        <div class="container mx-auto p-4 flex flex-col gap-12 items-center">
            <div class="w-full max-w-[800px] flex flex-col gap-6">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-center">
                    {{ __('Toutes les fonctionnalités qu\'un cabinet moderne mérite') }}
                </h2>
                <p class="text-x-black text-base text-center">
                    {{ __('Medicalink n\'est pas un simple logiciel de gestion de cabinet médical. C\'est un outil pensé pour vous faire gagner du temps, améliorer votre organisation, et vous aider à offrir un meilleur suivi à vos patients sans compromis. Chaque fonctionnalité a été développée avec l\'aide de vrais médecins marocains, pour répondre à leurs vrais besoins. Rien de superflu. Que du concret.') }}
                </p>
            </div>
            <div class="w-full flex flex-col gap-10">
                {{-- <div class="w-full grid grid-cols-1 grid-rows-1 gap-10 isolate">
                        @php
                            $Features = [
                                (object) [
                                    'image' => Neo::asset('img/appointment.png'),
                                    'head' => __('Gestion intelligente des rendez-vous'),
                                    'text' => __(
                                        'Planifiez vos consultations classiques ou spécialisées, gérez les annulations, les remplacements, et même les médecins délégués tout est fluide et connecté.',
                                    ),
                                ],
                                (object) [
                                    'image' => Neo::asset('img/patient.png'),
                                    'head' => __('Suivi patient complet'),
                                    'text' => __(
                                        'Dossier centralisé avec historique, traitements, radios, examens et ordonnances, toujours à jour et accessible en un clic.',
                                    ),
                                ],
                                (object) [
                                    'image' => Neo::asset('img/prescription.png'),
                                    'head' => __('Ordonnances, analyses et radios en ligne'),
                                    'text' => __(
                                        'Créez, imprimez et consultez tous vos documents médicaux en quelques secondes, sans quitter la plateforme.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M210-34q-57.12 0-96.56-40.14Q74-114.28 74-170v-541q0-57.13 39.44-96.56Q152.88-847 210-847h15v-79h113v79h284v-79h113v79h15q57.13 0 96.56 39.44Q886-768.13 886-711v541q0 55.72-39.44 95.86Q807.13-34 750-34H210Zm0-136h540v-541H210v541Zm123 0v-51.62L267-299q-12-14-23.5-36.6Q232-358.21 232-390q0-13 2.55-25.5Q237.09-428 242-440q-4-11-7-24t-3-26q0-30.56 11.5-53.78Q255-567 267-581l65-77v-53h114v74q0 13-12 35l-81 95q-3 4-5 8.25t-2 8.75q0 8 5 15.5t14 7.5q2 0 6-1.15 4-1.16 7-3.85 21-22 47.33-32.5t54.5-10.5q28.17 0 54.67 10.5T582-472q3 4 6.5 4.5t5.5.5q8.26 0 13.63-7 5.37-7 5.37-15 0-4.5-1.62-8.75Q609.77-502 607-506l-80-94q-3-3-8.5-12.5T513-637v-74h114v53l67 79q16.44 19.19 24.72 42.59Q727-513 727-489q0 13-2 25.5t-7 23.5q5 12 7.5 24.5T728-390q0 30.57-11 53.29Q706-314 693-299l-65 77.38V-170H514v-73.1q0-13.15 12-34.9l70-83q-2 2-2 4.5v4.5q-.02-1 .46-1h.54q-27 0-52-10.5T499-394q-3.37-3-7.82-5t-10.3-2q-5.35 0-11.08 1.5-5.72 1.5-8.8 5.5-18 19-43.15 30-25.16 11-52.85 11h.17q.83 0 .83 1v-4.5q0-2.5-2-4.5l70 83q5 7 9 15.5t4 19.5v73H333Zm-123 0v-541 541Z',
                                    'head' => __('Lecteur DICOM et radios intégré'),
                                    'text' => __(
                                        'Visualisez vos imageries médicales directement en ligne. Une première au Maroc, zéro logiciel externe requis.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M480-534q63 0 107.5-42.5T632-682v-108H328v108q0 63 44.5 105.5T480-534ZM114-34v-136h78v-108q0-57 21-108.5t60-93.5q-39-42-60-93.5T192-682v-108h-78v-136h732v136h-78v108q0 57-20.5 108.5T687-480q40 42 60.5 93.5T768-278v108h78v136H114Z',
                                    'head' => __('Salle d\'attente numérique'),
                                    'text' => __(
                                        'Gérez la file des patients en temps réel, améliorez le flux et réduisez l\'attente dans votre cabinet.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M275-274h90v-291h-90v291Zm160 0h90v-412h-90v412Zm160 0h90v-171h-90v171ZM212-76q-57.12 0-96.56-39.44Q76-154.88 76-212v-536q0-57.13 39.44-96.56Q154.88-884 212-884h536q57.13 0 96.56 39.44Q884-805.13 884-748v536q0 57.12-39.44 96.56Q805.13-76 748-76H212Zm0-136h536v-536H212v536Zm0-536v536-536Z',
                                    'head' => __('Tableau de bord de performance'),
                                    'text' => __(
                                        'Visualisez votre activité, suivez vos consultations, revenus et tendances médicales en un clin d\'œil.',
                                    ),
                                ],
                            ];
                        @endphp
                        @foreach ($Features as $Feature)
                            <div class="w-full rounded-2xl bg-x-white p-6 lg:px-10 lg:col-span-3 lg:sticky lg:bottom-10 border border-x-light shadow-md"
                                style="z-index: -{{ $loop->index }}">
                                <div
                                    class="w-full grid grid-cols-1 grid-rows-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center">
                                    <div class="w-full flex flex-col gap-6 lg:py-16">
                                        <h3 class="font-x-thin text-x-black text-xl lg:text-2xl lg:leading-[1] text-start">
                                            {{ $Feature->head }}
                                        </h3>
                                        <p class="text-x-black text-base text-start">
                                            {{ $Feature->text }}
                                        </p>
                                        <a href="https://carsrental.ma/fleet"
                                            class="group w-max flex outline-none text-x-prime hover:text-x-black focus-within:text-x-black">
                                            <div class="text-lg font-x-thin">
                                                {{ __('Read More') }}
                                            </div>
                                        </a>
                                    </div>
                                    @if (isset($Feature->image))
                                        <img src="{{ $Feature->image }}" alt="" loading="lazy"
                                            class="block w-full aspect-video object-contain object-center">
                                    @else
                                        <div class="bg-x-light aspect-video rounded-xl"></div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div> --}}
                <div class="w-full grid grid-cols-1 grid-rows-1 lg:grid-cols-3 gap-10 items-start">
                    <div class="w-full grid grid-cols-1 grid-rows-1 gap-10">
                        @php
                            $Features = [
                                (object) [
                                    'image' => Neo::asset('img/appointment.png'),
                                    'head' => __('Gestion intelligente des rendez-vous'),
                                    'text' => __(
                                        'Planifiez vos consultations classiques ou spécialisées, gérez les annulations, les remplacements, et même les médecins délégués tout est fluide et connecté.',
                                    ),
                                ],
                                (object) [
                                    'image' => Neo::asset('img/viewer.png'),
                                    'head' => __('Lecteur DICOM et radios intégré'),
                                    'text' => __(
                                        'Visualisez vos imageries médicales directement en ligne. Une première au Maroc, zéro logiciel externe requis.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M417-205h111v-40h40q23.25 0 39.13-16.38Q623-277.75 623-301v-139q0-23.25-15.87-39.13Q591.25-495 568-495H448v-29h175v-111h-80v-40H432v40h-40q-23.25 0-39.12 16.37Q337-602.25 337-579v139q0 23.25 15.88 39.12Q368.75-385 392-385h120v29H337v111h80v40ZM250-34q-55.73 0-95.86-39.44Q114-112.88 114-170v-620q0-57.13 40.14-96.56Q194.27-926 250-926h329l267 267v489q0 57.12-40.14 96.56Q765.72-34 710-34H250Zm0-136h460v-432L520.62-790H250v620Zm0 0v-620 620Z',
                                    'head' => __('Suivi monétaire et paiements patients'),
                                    'text' => __(
                                        'Gardez une vision claire de vos revenus, paiements partiels, impayés, et opérations liées à chaque consultation. Medicalink automatise le suivi des flux financiers, pour que vous sachiez toujours où vous en êtes sans tableur, sans prise de tête.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M-22-218v-85.49Q-22-356 28.5-389 79-422 160-422q1 0 2-.5t3-.5q-17 26-26 55.8-9 29.81-9 62.2v87H-22Zm240 0v-87q0-37 18.5-68t53.5-54q36-22 84.5-33.5T479.95-472Q538-472 586-460.5t83 33.5q36 23 54.5 54t18.5 68v87H218Zm612 0v-87q0-33.35-8.5-62.85T796-423q2 0 2.66.5.65.5 1.34.5 81.9 0 131.95 32.51Q982-356.98 982-303v85H830ZM363-335h235q-26-10-57-15.5t-60.5-5.5q-29.5 0-61.5 5.5T363-335ZM160.18-457Q122-457 94-484.27q-28-27.27-28-65.75 0-39.64 27.77-66.81T159.69-644q39.31 0 66.81 26.87 27.5 26.86 27.5 66.58 0 38.55-26.97 66.05-26.98 27.5-66.85 27.5Zm640 0Q762-457 734-484.27q-28-27.27-28-65.75 0-39.64 27.77-66.81T799.69-644q39.31 0 66.81 26.87 27.5 26.86 27.5 66.58 0 38.55-26.97 66.05-26.98 27.5-66.85 27.5ZM480-501q-58.33 0-100.17-41.83Q338-584.67 338-643q0-60 41.83-101 41.84-41 100.17-41 60 0 101 41t41 101q0 58.33-41 100.17Q540-501 480-501Zm.61-116q10.39 0 17.89-8.11 7.5-8.12 7.5-18.5 0-10.39-7.57-17.89-7.56-7.5-18.75-7.5-9.68 0-17.68 7.57-8 7.56-8 18.75 0 9.68 8.11 17.68 8.12 8 18.5 8Zm.39 282Zm-1-308Z',
                                    'head' => __('Multi-utilisateurs et rôles personnalisés'),
                                    'text' => __(
                                        'Ajoutez vos infirmiers et assistantes, avec des permissions claires et des notifications automatiques après chaque opération.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M312 11 186-84v-134h8q-57 0-96.5-39.5T58-354v-319q-26 0-44.5-18.7T-5-736q0-25.6 18.7-44.3Q32.4-799 58-799h128v-34h-19q-25.6 0-44.3-18.7Q104-870.4 104-896q0-25.6 18.7-44.3Q141.4-959 167-959h164q25.6 0 44.3 18.7Q394-921.6 394-896q0 25.6-18.7 44.3Q356.6-833 331-833h-19v34h128q25.6 0 44.3 18.7Q503-761.6 503-736q0 25.6-18.7 44.3Q465.6-673 440-673v319q0 57-39.5 96.5T304-218h8V11Zm399-88q-80 0-135.5-55.5T520-268v-320q0-80 55.5-135.5T711-779q80 0 135.5 55.5T902-588v320q0 80-55.5 135.5T711-77ZM184-344h130v-32h-40q-23.2 0-40.6-17.31-17.4-17.32-17.4-40.4Q216-458 233.4-475t40.6-17h40v-33h-40q-23.2 0-40.6-17.36-17.4-17.35-17.4-40.5 0-23.14 17.4-40.64T274-641h40v-32H184v329Zm527.12-309q-26.76 0-45.94 19.09Q646-614.81 646-588h130q0-27-19.06-46-19.05-19-45.82-19ZM646-384h130v-88H646v88Zm64.88 181q26.76 0 45.94-19.09Q776-241.19 776-268H646q0 27 19.06 46 19.05 19 45.82 19Zm.12-385Zm0 320Z',
                                    'head' => __('Gestion du stock médicale'),
                                    'text' => __(
                                        'Suivez vos consommables, sachez exactement ce qui est utilisé, quand, et pour quel patient.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M157-56q-62.92 0-106.96-44.14Q6-144.29 6-207.35q0-63.07 44.04-106.86T157-358h646q62.92 0 106.96 44.14Q954-269.71 954-206.65q0 63.07-44.04 106.86T803-56H157Zm0-126h646q11.22 0 18.11-6.94 6.89-6.94 6.89-18.24 0-11.3-6.89-18.06Q814.22-232 803-232H157q-11.23 0-18.11 6.94-6.89 6.94-6.89 18.24 0 11.3 6.89 18.06Q145.77-182 157-182Zm234-228q-27.6 0-47.8-20.2Q323-450.4 323-478v-344q0-27.6 20.2-47.8Q363.4-890 391-890h344q27.6 0 47.8 20.2Q803-849.6 803-822v344q0 27.6-20.2 47.8Q762.6-410 735-410H391Zm58-126h228v-228H449v228ZM6-498v-126h266v126H6Zm483-114h148v-112H489v112ZM86-691h186v-126H86v126Zm363 155v-228 228Z',
                                    'head' => __('Fournisseurs intégrés'),
                                    'text' => __(
                                        'Gardez la trace de vos commandes, de vos fournisseurs et de l\'historique d\'achat de votre cabinet.',
                                    ),
                                ],
                            ];
                        @endphp
                        @foreach ($Features as $Feature)
                            <div class="w-full rounded-2xl bg-x-white p-6 border border-x-light shadow-md">
                                <div class="w-full grid grid-cols-1 grid-rows-1 gap-6">
                                    <div class="w-full flex flex-col gap-6">
                                        <h3 class="font-x-thin text-x-black text-xl lg:text-2xl lg:leading-[1] text-start">
                                            {{ $Feature->head }}
                                        </h3>
                                        <p class="text-x-black text-base text-start">
                                            {{ $Feature->text }}
                                        </p>
                                        <a href="https://carsrental.ma/fleet"
                                            class="group w-max flex outline-none text-x-prime hover:text-x-black focus-within:text-x-black">
                                            <div class="text-lg font-x-thin">
                                                {{ __('Read More') }}
                                            </div>
                                        </a>
                                    </div>
                                    @if (isset($Feature->image))
                                        <img src="{{ $Feature->image }}" alt="" loading="lazy"
                                            class="block w-10/12 mx-auto object-contain object-center">
                                    @else
                                        <div class="bg-x-light aspect-video rounded-xl"></div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="w-full grid grid-cols-1 grid-rows-1 gap-10">
                        @php
                            $Features = [
                                (object) [
                                    'image' => Neo::asset('img/patient.png'),
                                    'head' => __('Suivi patient complet'),
                                    'text' => __(
                                        'Dossier centralisé avec historique, traitements, radios, examens et ordonnances, toujours à jour et accessible en un clic.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M480-534q63 0 107.5-42.5T632-682v-108H328v108q0 63 44.5 105.5T480-534ZM114-34v-136h78v-108q0-57 21-108.5t60-93.5q-39-42-60-93.5T192-682v-108h-78v-136h732v136h-78v108q0 57-20.5 108.5T687-480q40 42 60.5 93.5T768-278v108h78v136H114Z',
                                    'head' => __('Salle d\'attente numérique'),
                                    'text' => __(
                                        'Gérez la file des patients en temps réel, améliorez le flux et réduisez l\'attente dans votre cabinet.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M420-340h120v-100h100v-120H540v-100H420v100H320v120h100v100Zm60.15 308Q321.23-69.81 217.62-208.86 114-347.91 114-516.16v-275.28L480-928l366 136.56v274.84q0 168.8-103.47 307.8Q639.07-69.81 480.15-32ZM480-172q98-40 164-133.33 66-93.33 66-210.16v-182.48L480-783l-230 85.51v181.54q0 117.29 66 210.62T480-172Zm0-306Z',
                                    'head' => __('Gestion des cliniques externes'),
                                    'text' => __(
                                        'Vous exercez dans plusieurs lieux ? Medicalink vous permet de tout suivre dans une seule interface.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M210-34q-57 0-96.5-39.5T74-170v-447q-19-18.63-29.5-43.82Q34-686 34-715v-75q0-57 39.5-96.5T170-926h620q57 0 96.5 39.5T926-790v75q0 29-10.5 54.18Q905-635.63 886-617v447q0 57-39.5 96.5T750-34H210Zm0-545v411h542v-411H210Zm-41-135h623v-76H169v76Zm170 348h284v-116H339v116Zm142-8Z',
                                    'head' => __('Espace personnel du médecin'),
                                    'text' => __(
                                        'Stockez vos documents professionnels, vos notes et fichiers privés en toute sécurité.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M480.15-32Q321.23-69.81 217.62-208.86 114-347.91 114-516.16v-275.28L480-928l366 136.56v274.84q0 168.8-103.47 307.8Q639.07-69.81 480.15-32Zm-.28-140Q570-208 633.5-291.5T708-480.12H480V-783l-230 85.42v181.69q0 9.89.5 18.61.5 8.72 1.43 17.28h227.94v308Z',
                                    'head' => __('Sécurité niveau bancaire'),
                                    'text' => __(
                                        'Données cryptées, connexions protégées, serveurs sécurisés vos informations sont entre de bonnes mains.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M34-30v-765q0-57.13 39.44-96.56Q112.88-931 170-931h620q57.13 0 96.56 39.44Q926-852.13 926-795v459q0 57.12-39.44 96.56Q847.13-200 790-200H204L34-30Zm132-306h624v-459H170v456l-4 3Zm4 0v-459 459Z',
                                    'head' => __('Intégration WhatsApp'),
                                    'text' => __(
                                        'Envoyez des rappels automatiques à vos patients, ou lancez vos campagnes promotionnelles directement depuis la plateforme.',
                                    ),
                                ],
                            ];
                        @endphp
                        @foreach ($Features as $Feature)
                            <div class="w-full rounded-2xl bg-x-white p-6 border border-x-light shadow-md">
                                <div class="w-full grid grid-cols-1 grid-rows-1 gap-6">
                                    <div class="w-full flex flex-col gap-6">
                                        <h3 class="font-x-thin text-x-black text-xl lg:text-2xl lg:leading-[1] text-start">
                                            {{ $Feature->head }}
                                        </h3>
                                        <p class="text-x-black text-base text-start">
                                            {{ $Feature->text }}
                                        </p>
                                        <a href="https://carsrental.ma/fleet"
                                            class="group w-max flex outline-none text-x-prime hover:text-x-black focus-within:text-x-black">
                                            <div class="text-lg font-x-thin">
                                                {{ __('Read More') }}
                                            </div>
                                        </a>
                                    </div>
                                    @if (isset($Feature->image))
                                        <img src="{{ $Feature->image }}" alt="" loading="lazy"
                                            class="block w-10/12 mx-auto object-contain object-center">
                                    @else
                                        <div class="bg-x-light aspect-video rounded-xl"></div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="w-full grid grid-cols-1 grid-rows-1 gap-10">
                        @php
                            $Features = [
                                (object) [
                                    'image' => Neo::asset('img/prescription.png'),
                                    'head' => __('Ordonnances, analyses et radios en ligne'),
                                    'text' => __(
                                        'Créez, imprimez et consultez tous vos documents médicaux en quelques secondes, sans quitter la plateforme.',
                                    ),
                                ],
                                (object) [
                                    'image' => Neo::asset('img/dashboard.png'),
                                    'head' => __('Tableau de bord de performance'),
                                    'text' => __(
                                        'Visualisez votre activité, suivez vos consultations, revenus et tendances médicales en un clin d\'œil.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M199-26q-72.63 0-122.81-50.23Q26-126.47 26-199.16q0-71.87 50.23-121.85Q126.47-371 199.16-371q71.87 0 121.85 50.1Q371-270.8 371-199q0 16.95-2.5 33.48Q366-149 360-133v-60q28 11 58.33 17 30.34 6 61.67 6 129 0 219.5-90.5T790-480h136q0 92.38-34.94 173.62-34.95 81.25-95.57 141.87-60.62 60.62-141.87 95.56Q572.38-34 480-34q-44.31 0-86.66-8.5Q351-51 311-67q-24 20-52.5 30.5T199-26Zm-.32-135Q215-161 226-171.68q11-10.67 11-27Q237-215 225.95-226t-26.83-11q-17.12 0-27.62 11.05T161-199.12q0 17.12 10.68 27.62 10.67 10.5 27 10.5Zm281.48-146Q409-307 358-358.16t-51-122.32q0-71.17 51.16-121.84Q409.32-653 480.48-653q71.17 0 121.84 50.62Q653-551.77 653-480.16 653-409 602.38-358q-50.61 51-122.22 51ZM34-480q0-92.38 34.95-173.62 34.94-81.25 95.56-141.87 60.62-60.62 141.87-95.57Q387.62-926 480-926q44.31 0 86.66 8.5Q609-909 649-893q24-20 53.08-30.5Q731.17-934 762-934q72.44 0 122.22 49.78T934-762.16q0 72.28-49.78 122.72T762.16-589q-72.28 0-122.72-50.39Q589-689.79 589-762q0-17.16 3-33.08 3-15.92 8-31.92v60q-28-11-58.33-17-30.34-6-61.67-6-129 0-219.5 90.5T170-480H34Zm727.41-244Q777-724 788-735.38t11-26.5Q799-777 787.82-788q-11.17-11-26-11-14.82 0-26.32 11.18-11.5 11.17-11.5 26.47 0 15.29 10.91 26.32Q745.82-724 761.41-724ZM199-199Zm563-563Z',
                                    'head' => __('Suivi des paiements et opérations récurrentes'),
                                    'text' => __(
                                        'Facturation claire, paiements suivis, consultations répétées gérées sans efforts.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'm775-68 136-135-44-42-61 61v-148h-60v148l-63-61-41 42L775-68ZM480-788 276-671l204 119 204-119-204-117ZM74-326v-307q0-37 18-68.5t50-49.5l270-155q16-9 33.15-13.5 17.14-4.5 35-4.5 17.85 0 34.71 4.64Q531.72-914.73 548-906l270 155q32 18 50 49.5t18 68.5v153H750v-84L480-407 210-565v237l285 165V-6L142-209q-31.2-17.61-49.6-49.2Q74-289.78 74-326ZM775 0q-83 0-141.5-58.5T575-200q0-83 58.5-141.5T775-400q83 0 141.5 58.5T975-200q0 83-58.5 141.5T775 0ZM480-475Z',
                                    'head' => __('Mises à jour hebdomadaires'),
                                    'text' => __(
                                        'Chaque semaine, de nouvelles fonctionnalités demandées par les médecins eux-mêmes sont ajoutées.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M34-662v-264h264v136H170v128H34Zm0 628v-264h136v128h128v136H34Zm628 0v-136h128v-128h136v264H662Zm128-628v-128H662v-136h264v264H790Zm-86 406h61v61h-61v-61Zm0-123h61v61h-61v-61Zm-62 61h62v62h-62v-62Zm-61 62h61v61h-61v-61Zm-62-62h62v62h-62v-62Zm123-123h62v62h-62v-62Zm-61 62h61v61h-61v-61Zm-62-62h62v62h-62v-62Zm246-324v246H519v-246h246ZM441-441v246H195v-246h246Zm0-324v246H195v-246h246Zm-81 488v-83h-83v83h83Zm0-323v-83h-83v83h83Zm323 0v-83h-83v83h83Z',
                                    'head' => __(' QR Code pour prise de rendez-vous en ligne'),
                                    'text' => __(
                                        'Fini les files d\'attente devant la porte du cabinet à 7h du matin. Avec Medicalink, vos patients scannent un QR code affiché à l\'entrée et réservent leur rendez-vous en ligne simple, rapide et respectueux du temps de chacun.',
                                    ),
                                ],
                                (object) [
                                    'path' =>
                                        'M420-193q-58.4 0-97.2-39.5Q284-272 284-329v-11q-62-46-96-113.81-34-67.8-34-145.19 0-136.01 94.85-231.51 94.84-95.49 231-95.49t231.16 95.21Q806-735.58 806-600q0 76.82-34 145.41T677-340v11q0 57-39.5 96.5T541-193H420Zm-2-135h124v-82l48-33q38.05-27.32 60.02-68.37Q672-552.43 672-599.32q0-80.45-55.85-136.57Q560.3-792 479.93-792q-80.36 0-136.15 55.9Q288-680.21 288-600.03q0 48.03 22.26 88.91Q332.52-470.24 371-443l47 33v82ZM394-34q-27.95 0-47.48-19.67Q327-73.34 327-101.57V-168h306v67.21q0 28.14-19.28 47.47Q594.45-34 567-34H394Zm86-566Z',
                                    'head' => __('Une fonctionnalité manque ? On la crée.'),
                                    'text' => __(
                                        'Vous avez besoin d\'un outil spécifique à votre pratique ? Dites-le-nous notre équipe vous l\'intègre en moins de 48h. Medicalink évolue avec vous, pas contre vous.',
                                    ),
                                ],
                            ];
                        @endphp
                        @foreach ($Features as $Feature)
                            <div class="w-full rounded-2xl bg-x-white p-6 border border-x-light shadow-md">
                                <div class="w-full grid grid-cols-1 grid-rows-1 gap-6">
                                    <div class="w-full flex flex-col gap-6">
                                        <h3 class="font-x-thin text-x-black text-xl lg:text-2xl lg:leading-[1] text-start">
                                            {{ $Feature->head }}
                                        </h3>
                                        <p class="text-x-black text-base text-start">
                                            {{ $Feature->text }}
                                        </p>
                                        <a href="https://carsrental.ma/fleet"
                                            class="group w-max flex outline-none text-x-prime hover:text-x-black focus-within:text-x-black">
                                            <div class="text-lg font-x-thin">
                                                {{ __('Read More') }}
                                            </div>
                                        </a>
                                    </div>
                                    @if (isset($Feature->image))
                                        <img src="{{ $Feature->image }}" alt="" loading="lazy"
                                            class="block w-10/12 mx-auto object-contain object-center">
                                    @else
                                        <div class="bg-x-light aspect-video rounded-xl"></div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="w-full pt-8 lg:pt-20 relative isolate">
        <div class="absolute inset-0 w-full h-full -z-10">
            <div
                class="absolute w-full h-full inset-0 bottom-auto -z-10 bg-gradient-to-b from-transparent via-transparent to-x-light">
            </div>
        </div>
        <div class="container mx-auto p-4 grid grid-cols-1 grid-rows-1 lg:grid-rows-2 lg:grid-cols-3 gap-6 relative z-[1]">
            <div class="lg:row-span-2 lg:col-start-2 lg:row-start-1">
                <div class="w-full flex flex-col gap-6 my-auto py-10">
                    <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-center">
                        {{ __('Prêt à faire passer votre cabinet à un autre niveau ?') }}
                    </h2>
                    <p class="text-x-black text-base text-center">
                        {{ __('Rejoignez les nombreux médecins qui ont déjà choisi Medicalink pour simplifier leur quotidien et offrir un meilleur suivi à leurs patients.') }}
                    </p>
                </div>
            </div>
            <a href=""
                class="group w-full flex flex-col rounded-xl bg-x-white shadow-md border border-x-light p-6 outline-none hover:bg-x-acent focus-within:bg-x-acent">
                <div class="my-auto flex flex-wrap items-center gap-6">
                    <svg class="w-16 h-16 rouned-full text-x-prime group-hover:text-x-white group-focus-within:text-x-white"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M809.47-108q-127.93 0-254.05-56.08-126.11-56.08-230.69-160.34-104.57-104.27-160.65-230.7Q108-681.54 108-809.47q0-20.31 11-31.42Q130-852 150-852h168.46q15.54 0 27.43 9.89 11.88 9.88 16.03 24.42L388.85-670q2.38 14.38-1 26.15-3.39 11.77-10.16 17.77l-101.38 99.93q21.3 37.84 48.46 72.27 27.15 34.42 60.54 68.57 31.92 30.93 66 57.66 34.08 26.73 71.08 48.04l105.76-102.54q8.39-8.77 17.35-11.2 8.96-2.42 19.12-.42l151.07 32.62q15.15 4 25.73 15.46t10.58 26V-150q0 20-11.11 31t-31.42 11ZM235.92-606.92l63.39-60.31q1.92-1.54 2.5-4.23.58-2.69-.19-5l-16.39-83.39q-.77-3.07-2.69-4.61-1.92-1.54-5-1.54H203q-2.31 0-3.85 1.54-1.53 1.54-1.53 3.85 3.07 43 12.92 79.3 9.84 36.31 25.38 74.39Zm368 369.69q37.77 17.54 77.96 26.85 40.2 9.3 78.73 13.15 2.31 2 3.85-.54t1.54-4.85v-76.15q0-3.08-1.54-5t-4.61-2.69l-84-18.08q-2.31-.77-4.04-.19-1.73.58-3.66 2.5l-64.23 65Zm-368-369.69Zm368 369.69Z" />
                    </svg>
                    <div class="flex flex-col gap-2 text-x-black group-hover:text-x-white group-focus-within:text-x-white">
                        <h3 class="font-x-thin text-xl lg:leading-[1] text-start">
                            {{ __('Call us') }}
                        </h3>
                        <div class="text-lg text-start">
                            {{ __('+212666299469') }}
                        </div>
                    </div>
                </div>
            </a>
            <a href=""
                class="group w-full flex flex-col rounded-xl bg-x-white shadow-md border border-x-light p-6 outline-none hover:bg-x-acent focus-within:bg-x-acent">
                <div class="my-auto flex flex-wrap items-center gap-6">
                    <svg class="w-16 h-16 rouned-full text-x-prime group-hover:text-x-white group-focus-within:text-x-white"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M234-410h330v-60H234v60Zm0-135h492v-60H234v60Zm0-135h492v-60H234v60ZM68-76.46v-729.23q0-41.03 28.64-69.67T166.31-904h627.38q41.03 0 69.67 28.64T892-805.69v463.38q0 41.03-28.64 69.67T793.69-244H235.54L68-76.46ZM200-330h593.69q4.62 0 8.46-3.85 3.85-3.84 3.85-8.46v-463.38q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H166.31q-4.62 0-8.46 3.85-3.85 3.84-3.85 8.46v522.08L200-330Zm-46 0v-488 488Z" />
                    </svg>
                    <div class="flex flex-col gap-2 text-x-black group-hover:text-x-white group-focus-within:text-x-white">
                        <h3 class="font-x-thin text-xl lg:leading-[1] text-start">
                            {{ __('Contact') }}
                        </h3>
                        <div class="text-lg text-start">
                            {{ __('contact@medicalink.ma') }}
                        </div>
                    </div>
                </div>
            </a>
            <a href=""
                class="group w-full flex flex-col rounded-xl bg-x-white shadow-md border border-x-light p-6 outline-none hover:bg-x-acent focus-within:bg-x-acent">
                <div class="my-auto flex flex-wrap items-center gap-6">
                    <svg class="w-16 h-16 rouned-full text-x-prime group-hover:text-x-white group-focus-within:text-x-white"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M479.82-699.69q18.1 0 30.29-12.02 12.2-12.02 12.2-30.11 0-18.1-12.02-30.29-12.02-12.2-30.11-12.2-18.1 0-30.29 12.02-12.2 12.02-12.2 30.11 0 18.1 12.02 30.29 12.02 12.2 30.11 12.2ZM437-373.54h86v-243.54h-86v243.54ZM68-76.46v-729.23q0-41.03 28.64-69.67T166.31-904h627.38q41.03 0 69.67 28.64T892-805.69v463.38q0 41.03-28.64 69.67T793.69-244H235.54L68-76.46ZM200-330h593.69q4.62 0 8.46-3.85 3.85-3.84 3.85-8.46v-463.38q0-4.62-3.85-8.46-3.84-3.85-8.46-3.85H166.31q-4.62 0-8.46 3.85-3.85 3.84-3.85 8.46v522.08L200-330Zm-46 0v-488 488Z" />
                    </svg>
                    <div class="flex flex-col gap-2 text-x-black group-hover:text-x-white group-focus-within:text-x-white">
                        <h3 class="font-x-thin text-xl lg:leading-[1] text-start">
                            {{ __('Info') }}
                        </h3>
                        <div class="text-lg text-start">
                            {{ __('infot@medicalink.ma') }}
                        </div>
                    </div>
                </div>
            </a>
            <a href=""
                class="group w-full flex flex-col rounded-xl bg-x-white shadow-md border border-x-light p-6 outline-none hover:bg-x-acent focus-within:bg-x-acent">
                <div class="my-auto flex flex-wrap items-center gap-6">
                    <svg class="w-16 h-16 rouned-full text-x-prime group-hover:text-x-white group-focus-within:text-x-white"
                        viewBox="0 -960 960 960" fill="currentColor">
                        <path
                            d="M477.78-272.77q21.3 0 36.1-14.67 14.81-14.66 14.81-35.96 0-21.29-14.66-36.1-14.67-14.81-35.97-14.81-21.29 0-36.1 14.67-14.81 14.67-14.81 35.96t14.67 36.1q14.67 14.81 35.96 14.81ZM437.62-430h80.3q.39-21.08 2.27-34.32 1.88-13.25 7.5-25.68 6-12.23 17.19-24.73 11.2-12.5 27.04-28.35 22.93-20.92 38.16-45.77 15.23-24.84 15.23-59.3 0-58.93-44.58-89-44.58-30.08-100.27-30.08-59.84 0-96 31.88-36.15 31.89-49.77 73.81l71.39 28.62q3.54-15.46 18.88-38.58 15.35-23.12 56.27-23.12 34.39 0 50.08 19.08Q547-656.46 547-637.31q0 21.54-13 37.89-13 16.34-27.92 29.04-24.85 23-38.35 36.61-13.5 13.62-20.5 26.46-7 12.85-8.31 30.81-1.3 17.96-1.3 46.5ZM480-24.46 356.46-148H206.31q-41.03 0-69.67-28.64T108-246.31v-547.38q0-41.03 28.64-69.67T206.31-892h547.38q41.03 0 69.67 28.64T852-793.69v547.38q0 41.03-28.64 69.67T753.69-148H603.54L480-24.46ZM206.31-234h184.57L480-144.77l89.12-89.13h184.57q5.39 0 8.85-3.46t3.46-8.85v-547.48q0-5.39-3.46-8.85t-8.85-3.46H206.31q-5.39 0-8.85 3.46t-3.46 8.85v547.38q0 5.39 3.46 8.85t8.85 3.46ZM480-520Z" />
                    </svg>
                    <div class="flex flex-col gap-2 text-x-black group-hover:text-x-white group-focus-within:text-x-white">
                        <h3 class="font-x-thin text-xl lg:leading-[1] text-start">
                            {{ __('Support') }}
                        </h3>
                        <div class="text-lg text-start">
                            {{ __('supportt@medicalink.ma') }}
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </section>
    <section class="bg-x-light w-full pt-8 lg:pt-20 relative isolate">
        <div class="container mx-auto p-4 grid grid-cols-1 grid-rows-1 lg:grid-cols-5 items-start gap-10">
            <div class="w-full flex flex-col gap-6 lg:py-10 lg:col-span-2 lg:sticky lg:top-0">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-start">
                    {{ __('Recommandé par les médecins qui l\'utilisent au quotidien') }}
                </h2>
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-white bg-x-prime border-2 border-x-prime hover:bg-x-acent hover:border-x-acent focus-within:bg-x-acent focus-within:border-x-acent">
                    <div class="rounded-full text-lg font-x-thin px-6 py-1">
                        {{ __('Book Now') }}
                    </div>
                </a>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 grid-rows-1 gap-6 lg:col-span-3">
                <div class="flex flex-col gap-6">
                    @php
                        $Reviews = [
                            (object) [
                                'rate' => 5,
                                'name' => 'Mehdi Ghazal',
                                'content' => __(
                                    'Pour moi, ce qui fait la différence, c\'est la stabilité et la sécurité du système. Je n\'ai jamais eu de bug ou de perte de données. Et franchement, voir mes patients impressionnés par la qualité de l\'accueil et l\'organisation, ça me motive chaque jour.',
                                ),
                            ],
                            (object) [
                                'rate' => 5,
                                'name' => 'Mehdi Ghazal',
                                'content' => __(
                                    'Pour moi, ce qui fait la différence, c\'est la stabilité et la sécurité du système. Je n\'ai jamais eu de bug ou de perte de données. Et franchement, voir mes patients impressionnés par la qualité de l\'accueil et l\'organisation, ça me motive chaque jour.',
                                ),
                            ],
                        ];
                    @endphp
                    @foreach ($Reviews as $Review)
                        <div class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6">
                            <div class="flex flex-col gap-4">
                                <div class="flex flex-wrap items-center gap-4 text-x-black">
                                    @php
                                        $parts = explode(' ', trim($Review->name));
                                        $initials = isset($parts[1])
                                            ? strtolower(substr($parts[0], 0, 1) . substr($parts[1], 0, 1))
                                            : strtolower(substr($parts[0], 0, 2));
                                    @endphp
                                    <span
                                        class="w-12 h-12 rounded-full bg-x-prime flex items-center justify-center text-lg font-x-huge text-x-white">
                                        {{ strtoupper($initials) }}
                                    </span>
                                    <div class="flex-[1] flex flex-col gap-1">
                                        <span class="font-x-huge text-base">
                                            {{ ucwords($Review->name) }}
                                        </span>
                                        <div class="flex flex-wrap w-max gap-[3px] mb-1">
                                            @for ($i = 0; $i < 5; $i++)
                                                <svg class="block w-4 h-4 pointer-events-none {{ $i < $Review->rate ? 'text-yellow-500' : 'text-yellow-100' }}"
                                                    fill="currentcolor" viewBox="0 -960 960 960">
                                                    <path
                                                        d="M279.78-736.59 394-884q16.48-20.94 39.38-31.47Q456.29-926 480-926q25 0 47.67 10.53Q550.33-904.94 567-884l113.22 147.41L852-679q36 12 55 41.5t19 62.45q0 17.05-4.5 33.55Q917-525 906-510L797-353.41 801-187q0 47-34 79t-82 32q-2 0-23-2l-182-50-181.11 50.08Q293-76 287-75.5q-6 .5-12 .5-47.2 0-81.6-32.5Q159-140 160-188l4-165L53.79-510.33Q43-526 38.5-542.17 34-558.33 34-575q0-34 19.42-63.11Q72.84-667.21 109-679l170.78-57.59Z" />
                                                </svg>
                                            @endfor
                                        </div>
                                    </div>
                                </div>
                                <p class="text-base text-x-black">
                                    {{ $Review->content }}
                                </p>
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="flex flex-col gap-6 lg:mt-6">
                    @php
                        $Reviews = [
                            (object) [
                                'rate' => 5,
                                'name' => 'Mehdi Ghazal',
                                'content' => __(
                                    'Pour moi, ce qui fait la différence, c\'est la stabilité et la sécurité du système. Je n\'ai jamais eu de bug ou de perte de données. Et franchement, voir mes patients impressionnés par la qualité de l\'accueil et l\'organisation, ça me motive chaque jour.',
                                ),
                            ],
                            (object) [
                                'rate' => 5,
                                'name' => 'Mehdi Ghazal',
                                'content' => __(
                                    'Pour moi, ce qui fait la différence, c\'est la stabilité et la sécurité du système. Je n\'ai jamais eu de bug ou de perte de données. Et franchement, voir mes patients impressionnés par la qualité de l\'accueil et l\'organisation, ça me motive chaque jour.',
                                ),
                            ],
                        ];
                    @endphp
                    @foreach ($Reviews as $Review)
                        <div class="w-full rounded-xl bg-x-white shadow-md border border-x-light p-6">
                            <div class="flex flex-col gap-4">
                                <div class="flex flex-wrap items-center gap-4 text-x-black">
                                    @php
                                        $parts = explode(' ', trim($Review->name));
                                        $initials = isset($parts[1])
                                            ? strtolower(substr($parts[0], 0, 1) . substr($parts[1], 0, 1))
                                            : strtolower(substr($parts[0], 0, 2));
                                    @endphp
                                    <span
                                        class="w-12 h-12 rounded-full bg-x-prime flex items-center justify-center text-lg font-x-huge text-x-white">
                                        {{ strtoupper($initials) }}
                                    </span>
                                    <div class="flex-[1] flex flex-col gap-1">
                                        <span class="font-x-huge text-base">
                                            {{ ucwords($Review->name) }}
                                        </span>
                                        <div class="flex flex-wrap w-max gap-[3px] mb-1">
                                            @for ($i = 0; $i < 5; $i++)
                                                <svg class="block w-4 h-4 pointer-events-none {{ $i < $Review->rate ? 'text-yellow-500' : 'text-yellow-100' }}"
                                                    fill="currentcolor" viewBox="0 -960 960 960">
                                                    <path
                                                        d="M279.78-736.59 394-884q16.48-20.94 39.38-31.47Q456.29-926 480-926q25 0 47.67 10.53Q550.33-904.94 567-884l113.22 147.41L852-679q36 12 55 41.5t19 62.45q0 17.05-4.5 33.55Q917-525 906-510L797-353.41 801-187q0 47-34 79t-82 32q-2 0-23-2l-182-50-181.11 50.08Q293-76 287-75.5q-6 .5-12 .5-47.2 0-81.6-32.5Q159-140 160-188l4-165L53.79-510.33Q43-526 38.5-542.17 34-558.33 34-575q0-34 19.42-63.11Q72.84-667.21 109-679l170.78-57.59Z" />
                                                </svg>
                                            @endfor
                                        </div>
                                    </div>
                                </div>
                                <p class="text-base text-x-black">
                                    {{ $Review->content }}
                                </p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
    <section class="w-full pt-8 lg:pt-20 relative isolate">
        <div class="absolute inset-0 w-full h-full -z-10">
            <div
                class="absolute w-full h-1/2 inset-0 bottom-auto -z-10 bg-gradient-to-b from-x-light via-transparent to-transparent">
            </div>
        </div>
        <div class="container mx-auto p-4 flex flex-col items-center gap-10">
            <div class="w-full max-w-[800px] flex flex-col gap-6">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-center">
                    {{ __('Questions fréquentes') }}
                </h2>
                <p class="text-x-black text-base text-center">
                    {{ __('Des réponses claires à vos questions sur la plateforme Medicalink et son fonctionnement au quotidien.') }}
                </p>
            </div>
            <div class="w-full grid grid-cols-1 grid-rows-1 lg:grid-cols-3 gap-10">
                <div class="rounded-2xl shadow-md border-2 border-x-prime bg-x-white p-6 lg:p-10 flex flex-col gap-10">
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-2xl text-start">
                            {{ __('Basic') }}
                        </h3>
                        <p class="text-x-black text-base text-start font-x-thin">
                            <span class="font-x-huge text-7xl text-x-prime">299</span> / {{ __('Mois MAD') }}
                        </p>
                    </div>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Best choise if:') }}
                        </h3>
                        <ul class="flex flex-col gap-2">
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option A
                                </span>
                            </li>
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option B
                                </span>
                            </li>
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option C
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="flex flex-col gap-4">
                        <h3 class="font-x-thin text-x-black text-xl text-start">
                            {{ __('Includes:') }}
                        </h3>
                        <ul class="flex flex-col gap-2">
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option A
                                </span>
                            </li>
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option B
                                </span>
                            </li>
                            <li class="w-full flex flex-wrap items-center gap-2">
                                <svg class="block w-5 h-5 text-x-prime" viewBox="0 -960 960 960" fill="currentColor">
                                    <path
                                        d="M480-480Zm289.04-166q-51.23 0-87.13-35.86Q646-717.72 646-768.95q0-51.23 35.86-87.14Q717.72-892 768.95-892q51.23 0 87.14 35.86Q892-820.28 892-769.04q0 51.23-35.86 87.13Q820.28-646 769.04-646ZM480.07-68q-85.48 0-160.69-32.44t-130.84-88.05q-55.63-55.61-88.09-130.79Q68-394.46 68-479.93q0-85.48 32.45-160.69 32.44-75.21 88.06-130.84 55.62-55.63 130.81-88.09Q394.51-892 480-892q29.93 0 58.93 4.5 28.99 4.5 56.84 12.12-11.29 18.68-18.57 39.22-7.28 20.55-8.89 42.54-21.75-6-43.63-9.19Q502.79-806 480-806q-136 0-231 95t-95 231q0 136 95 231t231 95q136 0 231-95t95-231q0-22.79-3.69-44.66-3.69-21.88-8.69-44.65 21.99-1.61 41.99-8.57 20-6.97 38.77-18.89 8.62 27.85 13.12 57.18Q892-510.27 892-480q0 85.49-32.44 160.68-32.44 75.19-88.05 130.81-55.61 55.62-130.79 88.06Q565.54-68 480.07-68Zm-56.45-221.85 286.07-286.07q-21-6.46-40.77-16.7-19.78-10.23-35.92-26.53L423.23-409.38l-116-116.77L247.08-466l176.54 176.15Z" />
                                </svg>
                                <span class="text-x-black text-base text-start font-x-thin">
                                    Option C
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="w-full pt-8 lg:pt-20 relative isolate">
        <div class="container mx-auto p-4 flex flex-col items-center gap-10">
            <div class="w-full max-w-[800px] flex flex-col gap-6">
                <h2 class="font-x-thin text-x-black text-3xl lg:text-4xl lg:leading-[1] text-center">
                    {{ __('Questions fréquentes') }}
                </h2>
                <p class="text-x-black text-base text-center">
                    {{ __('Des réponses claires à vos questions sur la plateforme Medicalink et son fonctionnement au quotidien.') }}
                </p>
            </div>
            <div class="flex flex-col gap-4">
                @php
                    $Faqs = [
                        (object) [
                            'head' => __(' Est-ce que Medicalink est adapté à ma spécialité médicale ?'),
                            'text' => __(
                                'Oui. Que vous soyez généraliste, dentiste, gynécologue, urologue, gastro-entérologue ou orthopédiste, Medicalink propose des modules adaptés à chaque spécialité. Et si quelque chose manque, notre équipe peut l\'ajouter pour vous en moins de 48h.',
                            ),
                        ],
                        (object) [
                            'head' => __('Comment mes patients prennent rendez-vous avec Medicalink ?'),
                            'text' => __(
                                'Vos patients peuvent réserver en ligne via un lien, un QR code affiché au cabinet, ou directement depuis la future plateforme santé nationale. Chaque rendez-vous arrive automatiquement dans votre agenda Medicalink  fini les appels perdus et les erreurs de planning.',
                            ),
                        ],
                        (object) [
                            'head' => __('Est-ce que mes données sont sécurisées ?'),
                            'text' => __(
                                'Absolument. Medicalink utilise un chiffrement de niveau bancaire (AES-256), une authentification à double facteur (2FA) et un hébergement sécurisé au Maroc. Vos données et celles de vos patients ne quittent jamais un environnement contrôlé.',
                            ),
                        ],
                        (object) [
                            'head' => __('Est-ce que je peux gérer mes paiements avec Medicalink ?'),
                            'text' => __(
                                'Oui. Vous pouvez suivre tous les paiements, consultations impayées, avances et historiques de facturation. Le système relie chaque opération aux ordonnances, radios ou consommables utilisés pour une traçabilité parfaite.',
                            ),
                        ],
                        (object) [
                            'head' => __('Combien de temps faut-il pour commencer ?'),
                            'text' => __(
                                'Quelques minutes. Medicalink est 100% en ligne  pas d\'installation, pas de frais de mise en route. Créez votre compte, ajoutez votre équipe et commencez à utiliser la plateforme immédiatement. Et si vous avez besoin d\'aide, notre équipe est dispo 24h/24.',
                            ),
                        ],
                    ];
                @endphp
                @foreach ($Faqs as $Faq)
                    <neo-accordion name="faqs" caption="{{ $Faq->head }}"
                        {{ $loop->index === 0 ? 'expand' : '' }}>
                        {!! $Faq->text !!}
                    </neo-accordion>
                @endforeach
            </div>
        </div>
    </section>
    <section class="w-full relative isolate">
        <div class="absolute inset-0 w-full h-full overflow-hidden z-10 pointer-events-none">
            <div
                class="absolute w-full h-1/3 inset-0 top-auto z-10 bg-gradient-to-b from-transparent via-x-light/80 to-x-light">
            </div>
        </div>
        <div class="w-full container mx-auto p-4 flex flex-col gap-12 pt-12 lg:pt-20">
            <div class="w-full flex flex-col items-center gap-6">
                <h2 class="max-w-[1000px] font-x-thin text-x-black text-4xl lg:text-6xl lg:leading-[1] text-center">
                    {!! __(
                        'Le <span class="text-x-prime">meilleur</span> logiciel de gestion de <span class="text-x-prime">cabinet</span> médical au <span class="text-x-prime">Maroc</span>, toutes <span class="text-x-prime">spécialités</span> confondu',
                    ) !!}
                </h2>
            </div>
            <div class="max-w-[800px] w-max mx-auto flex flex-wrap items-center gap-4">
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-white bg-x-prime border-2 border-x-prime hover:bg-x-acent hover:border-x-acent focus-within:bg-x-acent focus-within:border-x-acent">
                    <div class="rounded-full text-lg font-x-thin px-6 py-1">
                        {{ __('Book Now') }}
                    </div>
                </a>
                <a href="https://carsrental.ma/fleet"
                    class="group w-max mt-2 flex p-1 outline-none rounded-full text-x-prime border-2 border-x-prime hover:text-x-white hover:border-x-x-black hover:border-y-x-black focus-within:text-x-white focus-within:border-x-x-black focus-within:border-y-x-black">
                    <div
                        class="rounded-full text-lg font-x-thin px-6 py-1 group-hover:bg-x-black group-focus-within:bg-x-black">
                        {{ __('Read More') }}
                    </div>
                </a>
            </div>
            <div class="max-w-[1000px] w-full mx-auto">
                <img src="https://rental-client.foxdigia.com/img/poster.png?v=0.51.1" alt="" loading="lazy"
                    class="w-full rounded-2xl bg-x-light border border-x-light" />
            </div>
        </div>
    </section>
@endsection
