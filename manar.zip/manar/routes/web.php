<?php

use Illuminate\Support\Facades\Route;

require __DIR__ . '/guest.php';

Route::group(
    ['prefix' => '/admin'],
    function () {

        require __DIR__ . '/preference.php';

        require __DIR__ . '/core.php';
        require __DIR__ . '/auth.php';
        require __DIR__ . '/user.php';
        require __DIR__ . '/blog.php';
        require __DIR__ . '/image.php';
        require __DIR__ . '/profile.php';

        require __DIR__ . '/appointment.php';
    }
);
