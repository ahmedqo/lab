<?php

use App\Http\Controllers\AppointmentController;
use Illuminate\Support\Facades\Route;

Route::post('/appointments/store', [AppointmentController::class, 'store_action'])->name('actions.appointments.store');
Route::get('/appointments/{date}/search', [AppointmentController::class, 'search_action'])->name('actions.appointments.search');

Route::group(['middleware' => ['auth']], function () {
    Route::get('/appointments/{id}/patch', [AppointmentController::class, 'patch_view'])->name('views.appointments.patch');

    Route::get('/appointments', [AppointmentController::class, 'index_action'])->name('actions.appointments.index');
    Route::patch('/appointments/{id}/patch', [AppointmentController::class, 'patch_action'])->name('actions.appointments.patch');
});
