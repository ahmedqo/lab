<?php

use  App\Functions\Neo;
use Illuminate\Support\Facades\Route;

function render_routes($prefix = false)
{
    Route::view('/', 'guest.index');
}

foreach (Neo::$Locales as $locale) {
    Route::group(['prefix' => '/' . $locale, 'middleware' => 'trans'], function () use ($locale) {
        render_routes($locale);
    });
}

render_routes();
