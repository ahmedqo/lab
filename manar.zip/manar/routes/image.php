<?php

use App\Http\Controllers\ImageController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['auth']], function () {
    Route::post('/images', [ImageController::class, 'index_action'])->name('actions.images.index');
    Route::post('/images/store', [ImageController::class, 'store_action'])->name('actions.images.store');
    Route::delete('/images/clear', [ImageController::class, 'clear_action'])->name('actions.images.clear');
});
