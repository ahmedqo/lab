<?php

use App\Functions\Neo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->integer('read_time')->nullable();

            foreach (Neo::languagesList() as $lang => $_) {
                $table->longText('title_' . $lang)->unique();
                $table->longText('content_' . $lang);
                $table->longText('meta_title_' . $lang)->nullable();
                $table->longText('meta_description_' . $lang)->nullable();
            }

            $table->longText('treatments')->nullable();
            $table->longText('services')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blogs');
    }
};
